# Pruebas V3.2 — 24 octubre 2026

- 22/22 pruebas de dominio aprobadas; inventario, presupuesto, permisos, idempotencia y entrega única.
- 8/8 pruebas React/JSDOM aprobadas: tres recorridos existentes y cinco casos de vista nativa, registro concurrente, rollback de almacenamiento, migración de cuentas antiguas y recuperación sin borrar datos corruptos. Se corrigió el ID accesible del título de diálogo detectado en la prueba nueva.
- Compilación TypeScript/Vite aprobada. JS principal: 425.56 KB / 124.52 KB gzip. Los ocho WebP suman 981890 bytes; originales intactos.
- Chrome: bienvenida sin PhoneFrame, navegación, diálogo accesible, canje demo (0 → 2), giro (2 → 1), premio e historial comprobados.
- Solo App cambió dentro de archivos protegidos; hash actualizado tras prueba del nuevo runtime. 28 comprobaciones de integridad aprobadas.
- Supabase: catálogo de RUCALETA-QA consultado en modo lectura; sin tablas CAPI. Sin escrituras ni migraciones. Autenticación y transacciones reales NO verificadas. Safari/iPhone físico no ejecutado.

## Registro anterior V3.1

- 22 pruebas de dominio aprobadas: recorrido completo 1–13, doble canje/giro/entrega, inventario, probabilidades, snapshots, roles, idempotencia, persistencia y cumplimiento Instagram por cuenta.
- 3 pruebas de interfaz React/JSDOM aprobadas: recorrido administrativo hasta entrega; bienvenida, registro, apertura Instagram, continuar, logout/login sin repetir requisito. Tercer caso: formularios de costos y presupuestos. Shell móvil sustituido en estas pruebas.
- Compilación TypeScript/Vite aprobada. Integridad de los 28 archivos protegidos del runtime aprobada.
- 4 pruebas del empaquetado/worker aprobadas.
- Navegador Chrome: bienvenida, acceso demo, canje CAPI-FIESTA26 (0 → 2 tokens), giro animado (2 → 1), resultado e historial comprobados. Panel y campañas V3.1 revisados en viewport iPhone. Sin errores de aplicación observados; se excluyen mensajes de la extensión del navegador.

Correcciones realizadas: UUID compatible con HTTP; Web Locks solo en navegador; cierres JSX; composición del pedestal y encaje de ambos botones de bienvenida. El test integral excedió 15 s por importación/transformación en este entorno; con límite 45 s finalizó en 16.8 s. No se repitieron pruebas de dominio tras cambios exclusivamente visuales/documentales.

No ejecutado: SQL propuesto contra Supabase/PostgreSQL, pruebas de RLS/concurrencia reales, Safari en dispositivo físico ni suite Playwright del runtime protegido. Son requisitos antes de producción. Advertencia de build: bundle principal ~640 KB / 194 KB gzip, pendiente medir en iPhone real. La autenticación y premios son simulados.

V3.1: suite de dominio completa aprobada tras cambiar elegibilidad; dos recorridos originales aprobados; prueba adicional de formularios de costos y presupuestos aprobada por separado tras corregir los nombres accesibles de los campos. Pruebas incluyen presupuesto reservado, costo histórico, FIFO, límites por categoría, cambio de día y dos giros concurrentes sin exceder gasto. SQL económico propuesto no ejecutado.
