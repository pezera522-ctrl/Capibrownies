import { NativeRuntime } from "./NativeUI";
import Prototype from "./Prototype";

export default function App() {
  return (
    <NativeRuntime>
      <Prototype />
    </NativeRuntime>
  );
}
