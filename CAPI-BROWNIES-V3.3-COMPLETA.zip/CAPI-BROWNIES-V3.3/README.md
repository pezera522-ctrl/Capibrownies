# CAPI BROWNIES — V3.3 — demo móvil de promociones

Inicio recomendado del ZIP: `bash CAPI-BROWNIES-V3.3/INICIAR.sh` desde la carpeta exterior y abrir el puerto 5173. No requiere instalar paquetes para probar la compilación. Consulta `ABRIR-V3.3.txt`. Incluye servidor estático independiente de Vite, recuperación de errores de renderizado y acabados visuales de ruleta y controles. No se ha verificado en un iPhone físico ni en un Codespace remoto del usuario.

Actualización: pantalla nativa sin marco ni teclado simulados; adaptación al teclado real y safe areas. Se conserva el diseño original. Registro local atómico, protección de doble clic en giro y configuración visual congelada durante cada resultado. Si el almacenamiento está dañado se ofrece respaldo y restauración explícita, sin borrar datos automáticamente.

Los ocho PNG originales se conservan; la aplicación carga derivados WebP (0.98 MB frente a 12.67 MB). El código del antiguo simulador se conserva en `src/mobile` para recuperación y no se monta en la aplicación.

Consulta de Supabase del 24/10/2026: solo se encontraron Rucaleta y RUCALETA-QA; el catálogo de QA no contiene tablas de CAPI. No se modificó ninguna base ni se creó infraestructura. Esta entrega sigue siendo DEMO y requiere backend validado antes de premios reales.

Aplicación móvil funcional de demostración. Premios, probabilidades, versiones, inventario, códigos, tokens, campañas, reclamaciones, entregas, evidencias y roles administrables. No requiere ni conecta una base de datos real.

## Abrir

El ZIP incluye `dist/client` con React y sus dependencias de ejecución ya compiladas. Para probar sin instalar paquetes: `python3 -m http.server 8000 --directory dist/client` y abrir `http://localhost:8000`. Para editar/recompilar, `package-lock.json` fija las dependencias y `npm ci` las instala. Los PNG originales están en `public/assets/capi`; el build usa sus derivados optimizados para evitar duplicarlos en el ZIP.

Node 24 recomendado. Desde esta carpeta:

```sh
npm ci
npm run dev -- --host 0.0.0.0
```

Abrir la dirección local mostrada por Vite. Sin sesión inicia en **Bienvenida**. Para probar administración: Iniciar sesión → Accesos de prueba: cliente y administración → Administración principal. El selector es exclusivamente de demostración.

También puedes crear una cuenta ficticia y volver a entrar con su correo/contraseña de prueba. Al abrir Instagram se completa el requisito de esa cuenta; no se comprueba seguimiento real. Foto opcional. Los siguientes accesos pasan directamente a la ruleta.

## Recorrido rápido

1. Gestionar premios → Nuevo premio → guardar. Edita también un premio existente.
2. Configurar ruleta → asigna seis premios y probabilidades que sumen 100% → Vista previa → Guardar borrador → Publicar borrador guardado → confirmar.
3. Gestión de códigos → Crear códigos → lote de 10 → tokens por código = 2 → generar → copiar uno.
4. Perfil superior → Cliente de demostración → pegar código → Validar → comprobar tokens → Girar ruleta.
5. Ver historial → abrir premio → Reclamar. El resultado “Inténtalo otra vez” se guarda como giro sin premio.
6. Volver a Administrador principal → Entregas → abrir premio → Confirmar entrega.

Para un recorrido determinista, asigna 100% al premio nuevo y 0% a los otros cinco; administración muestra esa configuración. Después puedes restaurar la versión inicial como borrador y publicarla.

La demo incluye el código editable `CAPI-FIESTA26`: 2 tokens, hasta 100 usuarios, un canje por usuario. Los números del panel provienen del estado local; no son métricas del negocio real.

## Módulos

- Inicio: métricas derivadas, búsqueda y actividad.
- Premios: CRUD sin eliminación destructiva, activación, imagen/icono/color, inventario total, expiración, plazo y condiciones; contadores de ganados/reclamados/pendientes.
- Ruleta: seis segmentos, porcentajes independientes, borradores, publicación, versiones históricas y restauración. Premios no elegibles se excluyen por stock, fechas, presupuestos y límites; los pesos restantes se normalizan. Sin elegibles no se gasta token.
- Códigos: manual, individual aleatorio, lotes, tokens, límite, campañas, caducidad, activación, revocación sin usos, búsqueda/filtros, canjes y CSV.
- Entregas: estado, identificador, ganador, condiciones históricas, reclamación, entrega única y cancelación con motivo.
- Campañas, participaciones, permisos y auditoría accesibles desde el menú.
- Cliente: bienvenida, perfil ficticio, cumplimiento por apertura de Instagram, canje, tokens, ruleta, historial y reclamación.

## Datos y límites

Estado no sensible en `localStorage` (`capi-promotions-demo-v1`), cuenta demo activa en `sessionStorage`. Las ventanas del mismo origen coordinan escrituras con Web Locks cuando está disponible; cada servicio serializa operaciones y hace commit completo de una copia. Si Web Locks no existe, usar una sola pestaña. Esto NO es seguridad de producción ni sincronización entre dispositivos.

No introduzcas información personal, contraseñas ni evidencias reales. Usa credenciales ficticias. Las imágenes de prueba son locales, hasta 450 KB; cuota del navegador limitada. Restaurar datos desde menú principal → Restaurar demostración (solo principal) borra cambios demo. Limpiar datos del navegador también reinicia la demo.

El acceso real se implementará con Supabase Auth. `DemoAuthService` guarda hashes de datos ficticios y sal en `demoIdentities`, dentro del mismo estado y commit que el usuario; mantiene compatibilidad con `capi-demo-identities-v3` de versiones anteriores. Los hashes no salen por `getView`, ni siquiera a administradores, pero el almacenamiento local sigue siendo manipulable: NO es autenticación segura. El cumplimiento de Instagram se guarda con fecha y método `link_open`; no verifica seguidores.

Requieren backend real: Auth/MFA y sesiones, permisos/RLS, sorteo e inventario transaccionales, canjes idempotentes entre dispositivos, almacenamiento privado de fotografías, auditoría inalterable y métricas de producción. No se ha conectado Supabase ni tocado RUCALETA.

## Pruebas

```sh
npm test
npm run test:ui
npm run build
npm run test:sites
npm run check:runtime
```

`test:ui` prueba los formularios React con JSDOM y sustituye únicamente el shell móvil; no es prueba de navegador. `test:runtime` pertenece al starter (Playwright) y no se ejecutó en esta entrega. Consulta `TEST_REPORT.md` para resultados y límites.

## Archivos para continuar

- `SUPABASE_IMPLEMENTATION.md`: contrato técnico de backend, permisos, tablas, concurrencia, API, pruebas y orden de migración.
- `sql-proposed/schema_proposal.sql`, `rewards_proposal.sql` y `transactions_proposal.sql`: SQL propuesto, NO ejecutado.
- `ASSETS.md`: recursos visuales y nombres de reemplazo.
- `MASTER_ORDER.md`: ampliación consolidada y criterios permanentes.
- `src/domain/service.ts`: dominio y MockService, independiente de la presentación.
- `src/Prototype.tsx`: pantallas y formularios; no premios fijos dentro del componente de ruleta.

El diseño utiliza los cinco mockups suministrados, con extensiones necesarias para el nuevo panel. Se integran los ocho recursos originales del repositorio, con nombres exactos. La ruleta es geometría programática para mantener premios, colores y porcentajes configurables; los iconos vienen de Phosphor, no de texto/emoji.

## Control económico V3.1

Premios → editar: costo interno MXN, categoría, stock, límite diario y por campaña, periodo, destacado o retirar. Campañas: presupuesto total/diario, máximo de premios, límites por categoría y periodo. Encima está el presupuesto diario global. Resumen muestra comprometido/entregado/promedio. Cada token usa la campaña de su código en orden FIFO. El costo se reserva al ganar; entregar no vuelve a cobrarlo. Datos iniciales de costo cero son ficticios: configura tus propios valores.

La pantalla del cliente conserva reglas y disponibilidad; porcentajes y costos quedan en administración. Las reglas explican que las oportunidades varían y no todos los giros ganan. Cliente y administrador se prueban con identidades explícitamente simuladas.

Copia anterior completa: checkpoint V3 `45d8d2d`, conservado antes de modificar el motor V3.1. El ZIP final incluye código, recursos originales, build estático y documentación. Para abrir el build sin compilar: `python3 -m http.server 8000 --directory dist/client`, después abrir la dirección local correspondiente (no abrir index.html por file://).
