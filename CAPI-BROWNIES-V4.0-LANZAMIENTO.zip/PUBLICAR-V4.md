# CAPI BROWNIES V4.0

## Publicar sin Codespaces

1. Descomprime CAPI-BROWNIES-V4.0-LANZAMIENTO.zip en la raíz pública de un alojamiento estático. `index.html` y `assets/` deben estar juntos. No subas la carpeta fuente al directorio público.
2. Conecta tu dominio en el alojamiento y activa HTTPS. Incluidos `_redirects` (Netlify/Pages), `vercel.json` (Vercel), `.htaccess` (Apache) y `404.html` de respaldo. En Nginx usa `try_files $uri $uri/ /index.html;`. Publicación prevista en la raíz del dominio, no en subcarpetas.
3. En el proyecto EXISTENTE Supabase `llfltkdrcrekhllmzfsw`, Auth / URL Configuration: Site URL = `https://TU-DOMINIO/`; Redirect URLs = esa misma URL y solo los orígenes realmente utilizados. El cliente envía su origen actual para confirmación y recuperación. No se cambió la configuración existente porque no se proporcionó dominio ni proveedor definitivo.
4. Prueba confirmación por correo, acceso del propietario, acceso de un cliente, canje único, giro, historial y entrega en ese dominio antes de activar premios reales.

Los clientes no instalan nada ni abren puertos. El ZIP de publicación está compilado, contiene imágenes y fuentes locales, y usa la API de Supabase existente. No contiene claves administrativas. Requiere Internet y disponibilidad del backend.

## Fuente editable independiente

El ZIP FUENTE conserva la estructura, servidor, SQL histórico, pruebas, imágenes originales y optimizadas, lockfile y compilación. Para futuras ediciones: Node 22.18+ compatible con las dependencias; `npm ci`, `npm run build`, `node scripts/release.mjs`. Publica el contenido de `release/public`. Las dependencias se reproducen con el lockfile; no se incluye node_modules.
`.env.example` contiene únicamente valores públicos. Las variables VITE se incorporan durante el build. No pongas claves secretas en ellas. No vuelvas a aplicar bootstrap.sql: la base ya existe.

## Verificación de esta entrega — 25 octubre 2026

- 34 pruebas de dominio, cadencia, servidor simulado, red y acceso remoto: aprobadas. Las 3 de acceso remoto verifican API pública y rechazo de acceso no autorizado contra Supabase real, sin modificar premios ni cuentas.
- 9 pruebas de interfaz: aprobadas (entorno de pruebas local, no correo real), incluida simulación de servicio bloqueado y recuperación con Reintentar.
- 5 pruebas de servidor estático/Worker: aprobadas. HTML, JavaScript, imagen, rutas Worker y métodos.
- Bienvenida abierta en Chrome desde el build servido estáticamente (sin Vite); conecta con Supabase y termina la carga. Esta comprobación no equivale a publicar en el dominio definitivo.
- Compilación TypeScript/Vite e integridad de 28 archivos runtime: aprobadas; aviso no crítico de bundle JS >500 KB, ~160 KB gzip.
- Base existente: dos cuentas y propietario vinculado; RLS y ausencia de permisos directos de lectura/escritura de clientes confirmados. No se borraron ni migraron datos.
- Pendientes críticos: sesión real de propietario y cliente, correo/recuperación y recorrido canje→giro→entrega en dominio final. No se ejecutaron premios reales. Safari iPhone físico y Android físico no probados.
- Supabase advierte protección de contraseñas filtradas desactivada: https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection . Activación/configuración pendiente; no se debilitó ninguna protección.
- Las tres tablas con RLS sin políticas son privadas y solo accesibles por servidor, intencionalmente. El motor conserva su agregado JSON con actualización atómica/versionada; para mucho tráfico requiere pruebas de carga y posterior normalización. Esta entrega no certifica capacidad de producción a escala.

## Cambios acotados

Integrado el arreglo anterior de publicación; eliminado el mensaje que exigía puertos. Esperas de sesión/API acotadas, reintento visible, errores recuperables, respuestas antiguas descartadas y vista administrativa no inferida de otro usuario. No hay reintento automático de mutaciones. Los giros conservan su idempotencia existente. Diseño, reglas comerciales y backend permanecen conservados.
