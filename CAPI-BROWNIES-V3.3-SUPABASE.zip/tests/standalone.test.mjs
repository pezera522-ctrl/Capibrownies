import {test} from 'node:test';
import assert from 'node:assert/strict';
import {server} from '../scripts/serve-demo.mjs';
test('Demo compilada: HTML, módulos, imágenes, rutas y métodos seguros',async()=>{
 const app=server();await new Promise(resolve=>app.listen(0,'127.0.0.1',resolve));
 const origin=`http://127.0.0.1:${app.address().port}`;
 try{
  const res=await fetch(origin);assert.equal(res.status,200);const html=await res.text();assert.match(html,/CAPI BROWNIES/);
  const script=html.match(/src="([^"]+\.js)"/)[1];const js=await fetch(origin+script);assert.equal(js.status,200);assert.match(js.headers.get('content-type'),/javascript/);
  assert.equal((await fetch(origin+'/assets/capi/optimized/capi-logo-completo.webp')).status,200);
  assert.equal((await fetch(origin+'/package.json')).status,404);
  assert.equal((await fetch(origin,{method:'POST'})).status,405);
 }finally{await new Promise(resolve=>app.close(resolve));}
});
