import React from 'react';
import {test,expect,afterEach} from 'vitest';
import {render,screen,fireEvent,cleanup} from '@testing-library/react';
import {NativeRuntime,BottomSheet,KeyboardInput,MobileScroll} from '../src/NativeUI';
import {MockService,MemoryStorage} from '../src/domain/service';
import {DemoAuthService} from '../src/domain/demoAuth';
afterEach(()=>{cleanup();localStorage.clear()});
test('Pantalla nativa sin marco ni teclado simulado, diálogo accesible y entrada normal',()=>{
 const {container}=render(<NativeRuntime><MobileScroll><KeyboardInput aria-label="Correo"/></MobileScroll><BottomSheet open title="Nuevo premio" onOpenChange={()=>{}}><button>Guardar</button></BottomSheet></NativeRuntime>);
 expect(container.querySelector('.phone-stage,.keyboard-dock,.device-menu-bar')).toBeNull();
 fireEvent.change(screen.getByLabelText('Correo'),{target:{value:'demo@prueba.test'}});expect((screen.getByLabelText('Correo') as HTMLInputElement).value).toBe('demo@prueba.test');
 expect(screen.getByRole('dialog',{name:'Nuevo premio'})).toBeTruthy();expect(screen.getByRole('button',{name:'Cerrar'})).toBeTruthy();
});
test('Registro concurrente único, acceso correcto y hashes privados en todas las vistas',async()=>{
 const storage=new MemoryStorage(),service=new MockService(storage),auth=new DemoAuthService(service);
 const results=await Promise.allSettled([auth.register('Cliente','igual@demo.test','prueba123','prueba123'),auth.register('Otro','igual@demo.test','prueba123','prueba123')]);
 expect(results.filter(x=>x.status==='fulfilled')).toHaveLength(1);expect(storage.load()!.users).toHaveLength(4);expect(storage.load()!.demoIdentities).toHaveLength(1);
 const user=await auth.login('IGUAL@demo.test','prueba123');expect(user.role).toBe('client');
 await expect(auth.login('igual@demo.test','equivocada')).rejects.toThrow('incorrectos');
 for(const id of ['guest','owner-demo',user.id])expect((await service.getView(id)).demoIdentities).toBeUndefined();
});
test('Fallo al persistir no crea usuarios huérfanos ni credenciales sueltas',async()=>{
 const storage=new MemoryStorage(),service=new MockService(storage),auth=new DemoAuthService(service),before=storage.load();
 storage.save=()=>{throw Error('Cuota llena')};
 await expect(auth.register('Cliente','cuota@demo.test','prueba123','prueba123')).rejects.toThrow('Cuota llena');expect(storage.load()).toEqual(before);
});
test('Cuenta V3 anterior conserva acceso y se migra al próximo registro',async()=>{
 const storage=new MemoryStorage(),service=new MockService(storage);const previous=storage.load()!;delete previous.demoIdentities;storage.save(previous);
 const {sha256}=await import('@noble/hashes/sha256');const {bytesToHex,utf8ToBytes}=await import('@noble/hashes/utils');const hash=(s:string)=>bytesToHex(sha256(utf8ToBytes(s)));
 localStorage.setItem('capi-demo-identities-v3',JSON.stringify([{userId:'client-demo',emailHash:hash('anterior@demo.test'),salt:'s',passwordHash:hash('sprueba123')}]));
 const auth=new DemoAuthService(service);expect((await auth.login('anterior@demo.test','prueba123')).id).toBe('client-demo');
 await auth.register('Nueva','nueva@demo.test','prueba123','prueba123');expect(storage.load()!.demoIdentities).toHaveLength(2);
 await service.execute('owner-demo','demo.reset');await expect(auth.login('anterior@demo.test','prueba123')).rejects.toThrow();
});
