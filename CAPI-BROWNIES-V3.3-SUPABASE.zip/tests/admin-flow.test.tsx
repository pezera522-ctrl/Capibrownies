import React from 'react';import {test,expect,vi} from 'vitest';import {render,screen,fireEvent,waitFor,within} from '@testing-library/react';
// Runtime gestures/phone/keyboard are template-owned. The app screens, form handlers,
// domain service and localStorage remain real; this test does NOT claim browser coverage.
vi.mock('../src/NativeUI',()=>({
 MobileScroll:({children,...p}:any)=><div {...p}>{children}</div>,KeyboardInput:React.forwardRef((p:any,ref:any)=><input {...p} ref={ref}/>),KeyboardTextarea:React.forwardRef((p:any,ref:any)=><textarea {...p} ref={ref}/>),
 BottomSheet:({open,title,children}:any)=>open?<div role="dialog" aria-label={title}>{children}</div>:null,
 Carousel:({children}:any)=><div>{children}</div>,useKeyboard:()=>({hide:()=>{}})
}));
const click=(name:string)=>fireEvent.click(screen.getByRole('button',{name,exact:true}));
const change=(label:string,value:string)=>fireEvent.change(screen.getByLabelText(label,{exact:true}),{target:{value}});
async function dialogGone(){await waitFor(()=>expect(screen.queryByRole('dialog')).toBeNull())}

test('Datos corruptos muestran recuperación sin sobrescribir el contenido',async()=>{
 localStorage.clear();sessionStorage.clear();localStorage.setItem('capi-promotions-demo-v1','{broken');vi.resetModules();const {default:App}=await import('../src/Prototype');const view=render(<App/>);
 expect(screen.getByRole('heading',{name:'No pudimos abrir tus datos de prueba'})).toBeTruthy();expect(screen.getByRole('button',{name:'Descargar copia de mis datos'})).toBeTruthy();expect(localStorage.getItem('capi-promotions-demo-v1')).toBe('{broken');view.unmount();
});

test('Formularios reales: los 13 pasos del recorrido administrativo y cliente',async()=>{
 localStorage.clear();sessionStorage.clear();vi.resetModules();const {default:App}=await import('../src/Prototype');const view=render(<App/>);
 await screen.findByRole('button',{name:'Iniciar sesión',exact:true});click('Iniciar sesión');click('Accesos de prueba: cliente y administración');fireEvent.click(screen.getByRole('button',{name:/Administración principal/}));await dialogGone();await screen.findByRole('heading',{name:'Panel de administrador'});
 click('Gestionar premios');click('Nuevo premio');change('Nombre del premio','Brownie especial QA');change('Descripción','Premio creado desde el formulario de prueba.');click('Guardar premio');await dialogGone();await screen.findByRole('heading',{name:'Brownie especial QA'});
 click('Editar Brownie gratis');change('Nombre del premio','Brownie clásico QA');click('Guardar premio');await dialogGone();await screen.findByRole('heading',{name:'Brownie clásico QA'});
 click('Abrir menú');click('Configurar ruleta');let stored=JSON.parse(localStorage.getItem('capi-promotions-demo-v1')!);const newId=stored.prizes.find((p:any)=>p.name==='Brownie especial QA').id;
 change('Premio del segmento 1',newId);for(let i=1;i<=6;i++)change(`Probabilidad ${i}`,i===1?'100':'0');click('Vista previa');expect(screen.getAllByText('100%').length).toBeGreaterThan(0);click('Guardar borrador');await screen.findByRole('button',{name:'Abrir borrador'});click('Publicar borrador guardado');click('Confirmar publicación');await dialogGone();await waitFor(()=>expect(JSON.parse(localStorage.getItem('capi-promotions-demo-v1')!).versions.find((v:any)=>v.status==='published').number).toBe(2));
 click('Códigos');click('Crear códigos');change('Cantidad de códigos','10');change('Tokens por código','2');click('Generar códigos únicos');await dialogGone();stored=JSON.parse(localStorage.getItem('capi-promotions-demo-v1')!);expect(stored.codes).toHaveLength(11);const code=stored.codes[1].value;
 click('Cambiar cuenta de demostración');fireEvent.click(screen.getByRole('button',{name:/Cliente de demostración/}));await dialogGone();await screen.findByRole('heading',{name:'Ingresa tu código'});change('Código promocional',code);click('Validar');await waitFor(()=>expect(screen.getByLabelText('Balance de tokens').textContent).toBe('2'));
 click('Girar ruleta');await screen.findByRole('dialog',{name:'Tu resultado'},{timeout:6000});expect(within(screen.getByRole('dialog')).getByRole('heading',{name:'Brownie especial QA'})).toBeTruthy();click('Ver mi premio');click('Reclamar premio');await dialogGone();
 click('Cambiar cuenta de demostración');fireEvent.click(screen.getByRole('button',{name:/Administración principal/}));await dialogGone();await screen.findByRole('heading',{name:'Panel de administrador'});click('Entregas');fireEvent.click(screen.getByRole('button',{name:/Brownie especial QA Reclamado/}));click('Confirmar entrega');await dialogGone();stored=JSON.parse(localStorage.getItem('capi-promotions-demo-v1')!);expect(stored.awards[0].status).toBe('delivered');expect(stored.movements.reduce((n:number,m:any)=>n+m.delta,0)).toBe(1);expect(stored.claims).toHaveLength(2);view.unmount();
});

test('Visitante: registro, enlace Instagram, estado por cuenta y login sin repetir requisito',async()=>{
 localStorage.clear();sessionStorage.clear();vi.resetModules();const {default:App}=await import('../src/Prototype');const view=render(<App/>);
 await screen.findByRole('button',{name:'Crear cuenta',exact:true});expect(screen.queryByRole('heading',{name:'Panel de administrador'})).toBeNull();click('Crear cuenta');
 change('Nombre','Cliente prueba');change('Correo electrónico','cliente@demo.test');change('Contraseña','demo12345');change('Confirmar contraseña','demo12345');click('Continuar');
 const link=await screen.findByRole('link',{name:'Seguir en Instagram'});expect(link.getAttribute('href')).toBe('https://www.instagram.com/capibrowniespr/');expect(link.getAttribute('target')).toBe('_blank');expect((screen.getByRole('button',{name:'Continuar a códigos'}) as HTMLButtonElement).disabled).toBe(true);
 fireEvent.click(link);await screen.findByText('Completado');expect((screen.getByRole('button',{name:'Continuar a códigos'}) as HTMLButtonElement).disabled).toBe(false);click('Continuar a códigos');await screen.findByRole('heading',{name:'Ingresa tu código'});
 click('Perfil');click('Cerrar sesión demo');await screen.findByRole('button',{name:'Iniciar sesión',exact:true});click('Iniciar sesión');change('Correo electrónico','cliente@demo.test');change('Contraseña','demo12345');click('¡Vamos a jugar!');await screen.findByRole('heading',{name:'Ingresa tu código'});expect(screen.queryByRole('link',{name:'Seguir en Instagram'})).toBeNull();
 const saved=JSON.parse(localStorage.getItem('capi-promotions-demo-v1')!);const account=saved.users.find((u:any)=>u.name==='Cliente prueba');expect(account.instagramCompletionMethod).toBe('link_open');expect(account.instagramCompletedAt).toBeTruthy();expect(saved.evidence).toHaveLength(0);view.unmount();
});

test('Presupuestos de campaña: formularios guardan costos y límites reales',async()=>{
 localStorage.clear();sessionStorage.clear();sessionStorage.setItem('capi-actor','owner-demo');vi.resetModules();const {default:App}=await import('../src/Prototype');const view=render(<App/>);await screen.findByRole('heading',{name:'Panel de administrador'});
 click('Presupuestos y campañas');change('Máximo diario global (MXN)','50');click('Guardar reglas');await waitFor(()=>expect(JSON.parse(localStorage.getItem('capi-promotions-demo-v1')!).settings.dailyBudgetCents).toBe(5000));
 click('Editar campaña');change('Presupuesto total (MXN)','100');change('Presupuesto diario (MXN)','25');change('Máximo total de premios','10');change('General','4');click('Guardar campaña');await dialogGone();let s=JSON.parse(localStorage.getItem('capi-promotions-demo-v1')!);expect(s.campaigns[0].budgetCents).toBe(10000);expect(s.campaigns[0].dailyBudgetCents).toBe(2500);expect(s.campaigns[0].categoryLimits.General).toBe(4);
 click('Premios');click('Editar Brownie gratis');change('Costo interno (MXN)','12.50');change('Límite diario del premio','2');change('Límite por campaña','5');click('Guardar premio');await dialogGone();s=JSON.parse(localStorage.getItem('capi-promotions-demo-v1')!);expect(s.prizes[0].costCents).toBe(1250);expect(s.prizes[0].dailyLimit).toBe(2);expect(s.prizes[0].campaignLimit).toBe(5);view.unmount();
});
