import test from 'node:test';
import assert from 'node:assert/strict';
import {seed} from '../src/domain/service.ts';

let handler;
globalThis.Deno={env:{get:key=>key==='SUPABASE_URL'?'https://backend.test':'server-secret'},serve:fn=>{handler=fn}};
await import('../server/capi-api.ts');
let state,version,owner,identities;
function setup(){state=seed();state.users=[];version=1;owner={id:1,email:'owner@example.test',user_id:null};identities={owner:{id:'owner',email:'owner@example.test',email_confirmed_at:'2026-01-01',user_metadata:{name:'Owner'}},client:{id:'client',email:'client@example.test',email_confirmed_at:'2026-01-01',user_metadata:{role:'owner'}},unverified:{id:'unverified',email:'owner@example.test',email_confirmed_at:null}};}
globalThis.fetch=async(url,options={})=>{
 const u=new URL(url),body=options.body?JSON.parse(options.body):null;
 if(u.pathname==='/auth/v1/user'){const id=options.headers.Authorization?.split('.').at(-1);return Response.json(identities[id]??{}, {status:identities[id]?200:401});}
 assert.equal(options.headers.apikey,'server-secret');
 if(u.pathname.endsWith('/rpc/capi_rate_limit'))return Response.json(true);
 if(u.pathname.endsWith('/rpc/capi_session_active'))return Response.json(body.p_session==='active-session');
 if(u.pathname.endsWith('/capi_owner')){if(options.method==='PATCH'&&!owner.user_id)owner.user_id=body.user_id;return Response.json([owner]);}
 if(u.pathname.endsWith('/capi_state')){
  if(options.method==='PATCH'){if(Number(u.searchParams.get('version').slice(3))!==version)return Response.json([]);state=structuredClone(body.document);version=body.version;return Response.json([{version}]);}
  return Response.json([{version,document:state}]);
 }
 throw Error('Unexpected request '+url);
};
async function call(token,action,payload={},actorId='owner',session='active-session'){const jwt='x.'+btoa(JSON.stringify({session_id:session}))+'.'+token;const r=await handler(new Request('https://api.test',{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+jwt}:{})},body:JSON.stringify({action,payload,actorId})}));return {status:r.status,...await r.json()};}
test('Servidor: un token de una sesión revocada no permite acceder',async()=>{setup();assert.equal((await call('client','view',{},'client','revoked')).status,401);assert.equal(version,1);});
test('Servidor: sin sesión no modifica datos; demo y JWT inventado se bloquean',async()=>{setup();assert.equal((await call(null,'code.create')).status,401);assert.equal((await call('inventado','view')).status,401);assert.equal((await call(null,'demo.user')).status,403);assert.equal(version,1);});
test('Servidor: propietario requiere correo confirmado; metadata y actorId no elevan permisos',async()=>{setup();assert.equal((await call('unverified','view')).status,403);const v=await call('client','view');assert.equal(v.data.users[0].role,'client');assert.equal((await call('client','settings.save',{dailyBudgetCents:0})).status,400);assert.equal(owner.user_id,null);const p=await call('owner','view');assert.equal(p.data.users.find(u=>u.id==='owner').role,'owner');assert.equal(owner.user_id,'owner');});
test('Servidor: códigos únicos, canje concurrente y giro atómico con inventario e historial',async()=>{setup();await call('owner','view');await call('client','view');await call('client','instagram.complete');const created=await call('owner','code.create',{count:1,tokens:1,maxUses:1,active:true,expiresAt:null,campaignId:'campaign-demo'});assert.equal(created.status,200);const value=created.data[0].value;assert.equal((await call('owner','code.create',{tokens:1,maxUses:2})).status,400);const redemptions=await Promise.all(['a','b'].map(requestId=>call('client','code.redeem',{value,requestId})));assert.equal(redemptions.filter(r=>r.status===200).length,1);const spins=await Promise.all(['s1','s2'].map(requestId=>call('client','spin',{versionId:'version-1',requestId})));assert.equal(spins.filter(r=>r.status===200).length,1);assert.equal(state.spins.length,1);assert.equal(state.redemptions.length,1);assert.equal(state.movements.reduce((n,m)=>n+m.delta,0),0);const successful=state.spins[0];assert.equal((await call('client','spin',{versionId:'version-1',requestId:successful.requestId})).data.id,successful.id);assert.equal(state.spins.length,1);});
