# Orden maestra consolidada — CAPI BROWNIES

La ampliación «Panel administrativo de control total» tiene prioridad sobre configuraciones estáticas anteriores. El sistema debe mantener:

1. Catálogo editable de premios: nombre, descripción, imagen/icono, color, activo, stock máximo, expiración, plazo/condiciones y conteos de ganados/reclamados/pendientes.
2. Ruleta dinámica de seis segmentos: probabilidades explícitas independientes de tamaño visual; borradores, previsualización, publicación, historial y restauración; no mezclar versiones ni alterar premios ganados.
3. Códigos manuales/aleatorios/lotes únicos: tokens, usos, vencimiento, campaña, activación, revocación segura, búsqueda, filtros, usuarios/fecha de canje y CSV.
4. Premios obtenidos: usuario, identificador, fecha, snapshot de condiciones, vencimiento, pendiente/reclamado/entregado/vencido/cancelado. Entrega única y cancelación autorizada.
5. Métricas derivadas del estado; demo etiquetada, nada de estadísticas de producción inventadas.
6. Principal protegido, secundarios con permisos y clientes sin privilegios. Mutaciones administrativas auditadas.
7. Implementación actual sin Supabase: MockService con persistencia local no sensible, restauración y todos los controles operativos; ninguna declaración de seguridad de producción.
8. Futuro backend: SUPABASE_IMPLEMENTATION.md obligatorio con DDL, FK/CHECK/índices, RLS/grants, transacciones, APIs, idempotencia, concurrencia, inventario, snapshots, migraciones y pruebas. No conectar DB ni añadir secretos todavía.
9. Aceptación automatizada: crear premio → editar otro → cambiar probabilidades → publicar → generar 10 códigos → asignar tokens → cliente demo → canjear → ver saldo → girar → resultado conforme → historial → administrar entrega.
10. Interfaz fundada en las cinco referencias del usuario (bienvenida, acceso, participación, ruleta, administración); recursos reemplazables por rutas estables. La nueva funcionalidad tiene prioridad sobre estadísticas o controles decorativos de las imágenes.

Cualquier entrega futura debe señalar claramente qué pruebas de backend faltan antes de habilitar producción. No reincorporar premios ni códigos como constantes del componente visual.

## Prioridad V3 y corrección final de Instagram

Preservar lógica existente. Integrar los ocho PNG originales con nombres exactos; no generar reemplazos. Bienvenida → registro/login → requisito por cuenta → ruleta. Nunca abrir administración automáticamente para visitantes. Movimiento reducido, audio optativo por gesto, giro alineado al índice adjudicado, historial y celebración.

«Seguir en Instagram» abre inmediatamente https://www.instagram.com/capibrowniespr/ y registra el requisito como completado. No pedir confirmación ni revisión. Mostrar palomita verde y habilitar continuar. Persistir por cuenta; foto completamente opcional. Esto no prueba seguimiento real. Supabase y RUCALETA quedan sin tocar.

## Prioridad V3.1

El motor ahora renormaliza pesos entre elegibles antes del sorteo y reserva costos al adjudicar. Excluir automáticamente por stock, pausa/retiro, fechas, límite diario/por campaña/categoría y presupuestos global diario y de campaña. Sin elegibles conservar token. Configuración económica solo administrativa; reglas claras y disponibilidad visibles al cliente, sin afirmar equiprobabilidad. Atribución de tokens FIFO. Preservar historial y copia V3. El motor real deberá ejecutarse transaccionalmente en servidor.
