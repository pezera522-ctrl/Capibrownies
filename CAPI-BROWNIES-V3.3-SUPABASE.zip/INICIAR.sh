#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null; then echo 'Se requiere Node.js 24. Codespaces ya incluye Node.js.'; exit 1; fi
if [ ! -f dist/client/index.html ]; then echo 'Falta la compilación. Ejecuta npm ci y npm run build dentro de esta carpeta.'; exit 1; fi
exec node scripts/serve-demo.mjs
