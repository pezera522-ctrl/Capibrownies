import {Component,type ReactNode} from 'react';
export class ErrorBoundary extends Component<{children:ReactNode},{message:string}>{
 state={message:''};
 static getDerivedStateFromError(error:Error){return {message:error.message||'Error inesperado'}}
 render(){return this.state.message?<main className="storage-recovery" role="alert"><h1>Vamos a intentarlo de nuevo</h1><p>No se borraron tus datos.</p><details><summary>Ver detalle del error</summary><pre style={{whiteSpace:'pre-wrap'}}>{this.state.message}</pre></details><button className="primary full" onClick={()=>location.reload()}>Volver a abrir</button></main>:this.props.children}
}
