import {forwardRef, useEffect, useRef, type PropsWithChildren, type HTMLAttributes, type InputHTMLAttributes, type TextareaHTMLAttributes} from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import './native.css';

const keyboard = {hide: () => {const element=document.activeElement;if(element instanceof HTMLElement)element.blur();}};
export const useKeyboard=()=>keyboard;
export const KeyboardInput=forwardRef<HTMLInputElement,InputHTMLAttributes<HTMLInputElement>>((props,ref)=><input {...props} ref={ref}/>);
export const KeyboardTextarea=forwardRef<HTMLTextAreaElement,TextareaHTMLAttributes<HTMLTextAreaElement>>((props,ref)=><textarea {...props} ref={ref}/>);
export function MobileScroll(props:HTMLAttributes<HTMLDivElement>){return <div {...props} className={`native-scroll ${props.className||''}`}/>}
export function Carousel({children,className='',contentClassName='',ariaLabel}:{children:React.ReactNode;className?:string;contentClassName?:string;ariaLabel?:string}){return <div className={`native-carousel ${className}`} role="region" aria-label={ariaLabel}><div className={contentClassName}>{children}</div></div>}
export function NativeRuntime({children}:PropsWithChildren){
 useEffect(()=>{const vv=window.visualViewport;const update=()=>{document.documentElement.style.setProperty('--visible-height',`${vv?.height??window.innerHeight}px`);document.documentElement.style.setProperty('--visible-top',`${vv?.offsetTop??0}px`)};update();vv?.addEventListener('resize',update);vv?.addEventListener('scroll',update);window.addEventListener('resize',update);return()=>{vv?.removeEventListener('resize',update);vv?.removeEventListener('scroll',update);window.removeEventListener('resize',update)}},[]);
 return <div className="native-app">{children}</div>;
}
export function BottomSheet({open,onOpenChange,title,description,children}:{open:boolean;onOpenChange:(open:boolean)=>void;title:string;description?:string;snap?:number;children:React.ReactNode}){
 const titleRef=useRef<HTMLHeadingElement>(null);
 return <Dialog.Root open={open} onOpenChange={onOpenChange}><Dialog.Portal><Dialog.Overlay className="native-overlay"/><Dialog.Content className="bottom-sheet native-sheet" {...(!description?{'aria-describedby':undefined}:{})} onOpenAutoFocus={e=>{e.preventDefault();titleRef.current?.focus()}}>
  <div className="native-sheet-heading"><Dialog.Title ref={titleRef} tabIndex={-1} className="sheet-title">{title}</Dialog.Title><Dialog.Close className="native-close" aria-label="Cerrar">×</Dialog.Close></div>
  {description&&<Dialog.Description>{description}</Dialog.Description>}
  <div className="sheet-content native-sheet-content">{children}</div>
 </Dialog.Content></Dialog.Portal></Dialog.Root>;
}
