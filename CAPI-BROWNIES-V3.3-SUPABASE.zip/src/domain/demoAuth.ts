import {sha256} from '@noble/hashes/sha256';
import {bytesToHex,utf8ToBytes} from '@noble/hashes/utils';
import {uid,type MockService,type User,type DemoIdentity} from './service';
const KEY='capi-demo-identities-v3';
const hash=(value:string)=>bytesToHex(sha256(utf8ToBytes(value)));
// Demo-only credentials. Not an authentication boundary. Never use for real accounts.
export class DemoAuthService {
 constructor(private service:MockService){}
 private entries():DemoIdentity[]{const state=this.service.storage.load();const entries=state?.demoIdentities??JSON.parse(localStorage.getItem(KEY)||'[]');return entries.filter((e:DemoIdentity)=>state?.users.some(u=>u.id===e.userId))}
 async register(name:string,email:string,password:string,confirm:string){
  if(!name.trim()||name.trim().length>50)throw new Error('Escribe tu nombre.');
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error('Revisa tu correo.');
  if(password.length<8)throw new Error('Usa al menos 8 caracteres.');
  if(password!==confirm)throw new Error('Las contraseñas no coinciden.');
  const emailHash=hash(email.trim().toLowerCase()),salt=uid();
  return await this.service.execute('guest','demo.register',{name,emailHash,salt,passwordHash:hash(salt+password),legacyEntries:this.entries()}) as User;
 }
 async login(email:string,password:string){const entry=this.entries().find(x=>x.emailHash===hash(email.trim().toLowerCase()));if(!entry||entry.passwordHash!==hash(entry.salt+password))throw new Error('Correo o contraseña demo incorrectos.');const view=await this.service.getView(entry.userId);return view.users.find(u=>u.id===entry.userId)!}
 reset(){localStorage.removeItem(KEY)}
}
