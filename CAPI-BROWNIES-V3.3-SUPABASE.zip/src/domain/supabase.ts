import {createClient} from '@supabase/supabase-js';
import type {PromotionService,State,User} from './service';

export const LIVE=import.meta.env.MODE!=='test'&&import.meta.env.VITE_CAPI_MODE!=='demo';
const url='https://llfltkdrcrekhllmzfsw.supabase.co';
// Publishable key is public by design; no privileged key belongs in this bundle.
export const supabase=LIVE?createClient(url,'sb_publishable_8tE8hK_0dO2haDqj52sv7w_RFsiyKYp'):null!;
export class SupabaseService implements PromotionService {
 async call(action:string,payload:Record<string,unknown>={}){
  const {data:{session}}=await supabase.auth.getSession();
  const r=await fetch(`${url}/functions/v1/capi-api`,{method:'POST',headers:{'Content-Type':'application/json',apikey:'sb_publishable_8tE8hK_0dO2haDqj52sv7w_RFsiyKYp',...(session?{Authorization:`Bearer ${session.access_token}`}:{})},body:JSON.stringify({action,payload})});
  const result=await r.json();if(!r.ok){const error=Object.assign(new Error(result.error||'No se pudo conectar. Intenta nuevamente.'),{definitive:r.status===400||r.status===401||r.status===403});throw error;}return result.data;
 }
 async getView(_actorId:string):Promise<State>{return this.call('view')}
 async execute(_actorId:string,action:string,payload:Record<string,unknown>={}){return this.call(action,payload)}
}
export class SupabaseAuthService {
 constructor(private service:SupabaseService){}
 async register(name:string,email:string,password:string,confirm:string):Promise<User>{
  if(!name.trim()||name.length>50)throw new Error('Escribe tu nombre.');
  if(password.length<10)throw new Error('Usa una contraseña de al menos 10 caracteres.');
  if(password!==confirm)throw new Error('Las contraseñas no coinciden.');
  const {data,error}=await supabase.auth.signUp({email:email.trim(),password,options:{data:{name:name.trim()}}});
  if(error)throw error;
  if(!data.session)throw new Error('Revisa tu correo y confirma tu cuenta. Después inicia sesión aquí.');
  return this.profile(data.session.user.id);
 }
 async login(email:string,password:string){const {data,error}=await supabase.auth.signInWithPassword({email:email.trim(),password});if(error)throw new Error('No pudimos iniciar sesión. Revisa tus datos y confirma tu correo.');return this.profile(data.user.id)}
 async profile(id:string){const view=await this.service.getView(id);const user=view.users.find(x=>x.id===id);if(!user)throw new Error('No se pudo cargar tu perfil.');return user}
 async recover(email:string){const {error}=await supabase.auth.resetPasswordForEmail(email.trim());if(error)throw error;}
 reset(){/* Demo reset is deliberately unavailable in the live service. */}
}
