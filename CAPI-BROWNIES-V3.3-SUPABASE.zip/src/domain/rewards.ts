import type {State,Prize,Campaign,Version} from './service';
export const dayKey=(time:number|string)=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/Mexico_City',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(time));
export const money=(cents:number)=>new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'}).format(cents/100);
export function funding(s:State,userId:string){let used=s.spins.filter(x=>x.userId===userId).length;for(const r of s.redemptions.filter(x=>x.userId===userId)){if(used<r.tokens)return r;used-=r.tokens;}return null}
export function campaignOpen(c:Campaign|undefined,now:number){return !c||(c.active&&(!c.startsAt||Date.parse(c.startsAt)<=now)&&(!c.expiresAt||Date.parse(c.expiresAt)>now))}
export function rewardMetrics(s:State,campaignId?:string,now=Date.now()){
 const a=s.awards.filter(x=>campaignId===undefined||x.campaignId===campaignId), today=a.filter(x=>dayKey(x.createdAt)===dayKey(now)),spins=s.spins.filter(x=>campaignId===undefined||x.campaignId===campaignId);
 const committed=a.reduce((n,x)=>n+(x.costCents??0),0),delivered=a.filter(x=>x.status==='delivered').reduce((n,x)=>n+(x.costCents??0),0);
 return {committed,delivered,daily:today.reduce((n,x)=>n+(x.costCents??0),0),average:spins.length?committed/spins.length:0,awards:a.length,spins:spins.length};
}
export function eligibility(s:State,p:Prize,campaignId:string|null,now=Date.now()):string|null{
 const c=campaignId?s.campaigns.find(x=>x.id===campaignId):undefined;
 if(campaignId&&!c)return 'Campaña no disponible';if(!campaignOpen(c,now))return 'Campaña pausada o fuera de periodo';
 if(!p.active)return 'Pausado';if(p.retired)return 'Retirado';if(p.startsAt&&Date.parse(p.startsAt)>now)return 'Aún no comienza';if(p.expiresAt&&Date.parse(p.expiresAt)<=now)return 'Vencido';
 if(p.kind==='retry')return null;
 if(p.max!==null&&p.issued>=p.max)return 'Inventario agotado';
 const awards=s.awards.filter(a=>a.prizeId===p.id),campaignAwards=s.awards.filter(a=>(a.campaignId??null)===campaignId),today=dayKey(now),cost=p.costCents??0;
 if(p.dailyLimit!=null&&awards.filter(a=>dayKey(a.createdAt)===today).length>=p.dailyLimit)return 'Límite diario alcanzado';
 if(p.campaignLimit!=null&&campaignAwards.filter(a=>a.prizeId===p.id).length>=p.campaignLimit)return 'Límite del premio en campaña';
 if(c?.maxAwards!=null&&campaignAwards.length>=c.maxAwards)return 'Máximo de premios de campaña';
 const category=p.category||'General',categoryLimit=c?.categoryLimits?.[category];
 if(categoryLimit!=null&&campaignAwards.filter(a=>(a.snapshot.category||'General')===category).length>=categoryLimit)return 'Límite de categoría';
 const global=rewardMetrics(s,undefined,now),cm=rewardMetrics(s,campaignId??undefined,now);
 if(s.settings?.dailyBudgetCents!=null&&global.daily+cost>s.settings.dailyBudgetCents)return 'Presupuesto diario global';
 if(c?.dailyBudgetCents!=null&&cm.daily+cost>c.dailyBudgetCents)return 'Presupuesto diario de campaña';
 if(c?.budgetCents!=null&&cm.committed+cost>c.budgetCents)return 'Presupuesto total de campaña';
 return null;
}
export function rewardPool(s:State,v:Version,campaignId:string|null,now=Date.now()){
 const pool=v.segments.map((seg,index)=>{const p=s.prizes.find(p=>p.id===seg.prizeId);const reason=!p?'Premio no disponible':eligibility(s,p,campaignId,now)||((seg.snapshot.expiresAt&&Date.parse(seg.snapshot.expiresAt)<=now)?'Condiciones vencidas':null);return {index,weight:!reason?seg.probability:0,reason};});
 const total=pool.reduce((n,x)=>n+x.weight,0);return pool.map(x=>({...x,effective:total?x.weight/total*100:0}));
}
