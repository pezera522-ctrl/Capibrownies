// Short synthesized feedback, enabled only by an explicit user gesture.
export class CapiAudio {
 private context:AudioContext|null=null;
 private tone(at:number,freq:number,duration=.055){const c=this.context;if(!c)return;const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=freq;g.gain.setValueAtTime(0,at);g.gain.linearRampToValueAtTime(.045,at+.008);g.gain.exponentialRampToValueAtTime(.001,at+duration);o.connect(g);g.connect(c.destination);o.start(at);o.stop(at+duration+.01)}
 async enable(){try{const C=window.AudioContext||(window as any).webkitAudioContext;if(!C)return false;this.context??=new C();await this.context!.resume();return true}catch{return false}}
 spin(){const c=this.context;if(!c||c.state!=='running')return;[.05,.13,.23,.35,.50,.68,.9,1.17,1.49,1.87,2.3].forEach((t,i)=>this.tone(c.currentTime+t,900-i*25));}
 win(){const c=this.context;if(!c||c.state!=='running')return;[523,659,784,1046].forEach((f,i)=>this.tone(c.currentTime+i*.11,f,.18))}
 stop(){this.context?.close();this.context=null}
}
