import { NativeRuntime } from "./NativeUI";
import Prototype from "./Prototype";
import { ErrorBoundary } from "./ErrorBoundary";

export default function App() {
  return (
    <NativeRuntime>
      <ErrorBoundary><Prototype /></ErrorBoundary>
    </NativeRuntime>
  );
}
