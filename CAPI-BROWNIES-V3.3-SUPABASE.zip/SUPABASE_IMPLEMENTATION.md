# CAPI BROWNIES — implementación de Supabase

## Estado actualizado — 24 octubre 2026

La integración inicial REAL está descrita en README.md y CONTINUAR_AQUI.md. Usa Auth, Edge Function capi-api y agregado privado JSONB con commit atómico PostgreSQL. SQL aplicado en server/bootstrap.sql y server/session-validation.sql. El frontend usa SupabaseService; no acepta roles ni balances del navegador. El correo propietario requiere confirmación y se vincula a un UUID. No se han creado las tablas normalizadas de la propuesta histórica inferior. Esa normalización, carga, SMTP, URL Auth y validación remota completa son pendientes, no funciones verificadas. La cadencia admite giros o canjes y la ruleta 3–20 segmentos.

## Propuesta histórica de normalización (NO aplicada)

**Estado: especificación y SQL propuesto; ninguna base de datos conectada.** La demo usa datos locales simulados. No equivale a autenticación, autorización, auditoría inalterable ni concurrencia segura de producción. El SQL de `sql-proposed/` no se ha aplicado ni validado contra PostgreSQL/Supabase: el siguiente agente debe ejecutar las pruebas descritas antes de habilitar clientes reales.

## 1. Arquitectura y punto de sustitución

- Interfaz React: `src/Prototype.tsx`; estilos: `src/prototype.css`.
- Dominio: `src/domain/service.ts`. `PromotionService` expone `getView(actorId): Promise<State>` y `execute(actorId, action, payload): Promise<unknown>`.
- Actual: `MockService` + `BrowserStorage` en `Prototype.tsx`. Cambiar la construcción por `SupabaseService` sin reescribir los formularios ni la ruleta. Mover la factoría a `src/services/provider.ts` al conectar.
- Futuro `getView` obtiene vistas paginadas y proyecciones del servidor; adaptarlas a los DTO camelCase actuales. En producción eliminar `actorId` como autoridad: usar exclusivamente el usuario de sesión autenticado.
- `execute` mapea las acciones de esta especificación a Edge Functions. Validar JWT con `auth.getUser(token)` o una verificación de firma/claims oficial equivalente; validar sesión revocada en operaciones sensibles. No confiar en `getSession()` del navegador para autorizar.
- Edge utiliza un cliente privado separado con secreto de servidor para RPC `capi_server_*`. Estos RPC son `SECURITY INVOKER`, ejecutables solo por `service_role`. No se concede ejecución a `authenticated` ni `anon`. Se deriva `p_actor` del JWT verificado, nunca del cuerpo JSON.
- El único `SECURITY DEFINER` propuesto es `capi_private.has_permission`, usado en políticas SELECT: sin actor externo, `auth.uid()` obligatorio, `search_path=''`, esquema no expuesto, permisos mínimos. No resuelve mutaciones.
- El navegador solo recibe publishable key y URL de proyecto. Ninguna service key en Vite, repositorio o archivo público. No hay claves reales en esta entrega.
- En producción eliminar el selector de cuentas, `demo.user`, `demo.reset` y localStorage del dominio. El registro/login pasa a Supabase Auth, con email confirmado y MFA para administradores. Nada de migrar saldos, roles o premios simulados.

## 2. Decisiones de negocio cerradas

1. Seis segmentos visuales iguales, probabilidad independiente. La configuración y porcentajes efectivos se muestran solo en administración. El cliente ve reglas que indican oportunidades distintas y variables por disponibilidad, nunca la frase “mismas oportunidades”. Internamente usar enteros en puntos básicos: 1% = 100 bps, suma exacta 10,000. Duplicar el mismo premio en varios segmentos está permitido; su probabilidad total es la suma.
2. Los premios iniciales son semillas editables: Brownie gratis, Descuento del 10%, Promoción 2×1, Topping extra, Envío gratis, Inténtalo otra vez. La demo arranca con 15/25/10/20/10/20%; son valores demostrativos, no una decisión comercial permanente.
3. `retry` consume el token, guarda el giro y **no** crea premio ni entrega token extra. La interfaz lo dice expresamente.
4. El inventario es cantidad máxima adjudicable, no existencias vendibles. `disponible=capacity-awarded`; `NULL` significa ilimitado. El premio se reserva al ganar. Entregar no descuenta otra unidad. Cancelar/vencer no devuelve automáticamente inventario ni tokens. Una reposición requiere ajuste administrativo con auditoría.
5. V3.1: excluir segmentos agotados, pausados, retirados, fuera de periodo o de límites/presupuesto. Normalizar pesos únicamente entre elegibles antes de sortear. Si no hay ninguno, no consumir token. No sustituir un resultado después del sorteo. Los segmentos no elegibles muestran «No disponible».
6. Catálogo, inventario y versiones son entidades distintas. Editar imagen, color, nombre o condiciones no cambia una versión publicada: guardar/publicar un nuevo borrador. Las desactivaciones, agotamiento y vencimiento son comprobaciones de disponibilidad inmediata.
7. El premio ganado guarda snapshot completo y plazo: `expires_at=min(fecha_ganado+claimDays, expiresAt_original)`. Nunca extender ni reducir retroactivamente al editar catálogo. Cambios excepcionales requieren una función nueva explícita y auditada, fuera de esta versión.
8. Restaurar una versión crea un **nuevo borrador** con sus snapshots/probabilidades originales, conservando el inventario actual; publicar exige recalcular disponibilidad antes de cada giro.
9. Cada usuario canjea cada código una vez. `maxUses` limita usos totales entre usuarios. Una campaña inactiva/vencida impide nuevos canjes. No revoca tokens ya entregados.
10. Después del primer canje, texto de código, tokens/canje y campaña quedan bloqueados; solo estado, vencimiento y máximo >= usos actuales pueden editarse. Revocación permanente solo con cero usos. Los canjes existentes guardan tokens y campaña originales.
11. Principal único, protegido contra cambios de rol desde la aplicación. Secundario tiene permisos granulares. No se concede gestión de roles a secundarios. Transferir titularidad futura exige operación separada fuera del panel ordinario.
12. Estados: pendiente → reclamado (ganador); pendiente/reclamado → entregado (permiso deliveries); pendiente/reclamado → cancelado (deliveries, motivo obligatorio); pendiente/reclamado vencidos → vencido. Terminales no reabren ni se entregan. Se puede entregar directamente un pendiente al presentarse el ganador.

13. Abrir `https://www.instagram.com/capibrowniespr/` completa el requisito promocional una vez por cuenta. No hay confirmación, revisión obligatoria ni verificación real de seguidores. Foto opcional.

## 3. Modelo de datos

Los **DDL completos**, tipos, FK, CHECK, UNIQUE, índices y políticas se encuentran en `sql-proposed/schema_proposal.sql`. Relaciones clave:

| Tabla | PK | Datos principales / relaciones |
|---|---|---|
| `auth.users` | uuid | Supabase Auth; no duplicar contraseñas en perfiles |
| `profiles` | id → auth.users | display_name text, instagram_requirement_completed_at timestamptz, fechas |
| `capi_private.admin_roles` | user_id → profiles | enum owner/admin, permissions text[], revision bigint, granted_by uuid |
| `prizes` | uuid | name/description/conditions text, kind text, icon/image_path/color, active, expires_at, claim_days, revision |
| `prize_inventory` | prize_id → prizes | capacity bigint nullable, awarded bigint, revision, CHECK awarded<=capacity |
| `campaigns` | uuid | name/description, active boolean, expires_at, revision |
| `wheel_versions` | uuid | version bigint identity UNIQUE, status enum, restored_from FK, created_by, published_at, revision |
| `wheel_segments` | (version_id,position) | position 0–5, prize_id FK, probability_bps integer, prize_snapshot jsonb |
| `capi_private.runtime` | singleton boolean | published_version_id FK, revision; exclusión mutua para sorteo/publicación/inventario |
| `promo_codes` | uuid | code uppercase UNIQUE, campaign_id FK, tokens, max_uses, uses, active, revoked_at/expires_at, revision |
| `code_redemptions` | uuid | user_id/code_id/campaign_id FK; code_snapshot, tokens_granted; request_id UNIQUE por usuario; UNIQUE user+code |
| `token_balances` | user_id FK | balance bigint>=0, revision, updated_at |
| `token_movements` | uuid | user_id, delta int, kind code/spin, redemption_id o spin_id único, nunca ambos |
| `spins` | uuid | user_id/version_id, segment FK compuesto, snapshot, request_id único por usuario, draw_bps generado servidor |
| `awarded_prizes` | uuid | reference uuid UNIQUE, user/prize/version/spin FK; spin UNIQUE, snapshot, condiciones, vencimiento y estado |
| `claim_events` | uuid | award/actor FK, previous/next_status, note, request_id, fecha; una sola entrega por premio |
| `instagram_evidence` | uuid | user FK, kind follow/photo, handle, storage_path, status, reviewed_by, review_note, fechas |
| `capi_private.admin_audit` | bigint identity | actor/action/entity, before/after jsonb, request_id, fecha |

Todos los timestamps son `timestamptz` UTC. Presentación al cliente en `America/Mexico_City`. Usar UUID reales; los IDs `*-demo` no se migran. Dinero no forma parte de este sistema: los tokens son oportunidades promocionales, no saldo monetario.

### Snapshots

Contrato JSON de `prize_snapshot` (validar estrictamente en Edge y función de guardado):

```json
{"id":"uuid","name":"Brownie gratis","description":"...","kind":"prize","icon":"brownie","image":"/assets/capi/premio-brownie.png","color":"#ffe2ac","conditions":"Presentar identificador","claimDays":7,"expiresAt":null,"revision":1}
```

Conservar imágenes versionadas con rutas por hash o UUID. No reemplazar el contenido de un objeto usado en snapshots; subir otro. De lo contrario la imagen histórica cambiaría aunque el JSON fuera inmutable. Aplicar CHECK JSON Schema mediante extensión compatible si se dispone de ella o validación explícita de todas las claves/tipos en la función de borrador.

## 4. Permisos y RLS

- Activar RLS en **todas** las tablas expuestas, y como defensa adicional en privadas.
- `anon`: ningún SELECT de datos personales ni escritura ni RPC de servidor. La portada se sirve estática.
- `authenticated` cliente: SELECT de su perfil, saldo, ledger, canjes, giros, premios, eventos y evidencias. Puede consultar ruleta publicada y premios visibles. Ningún INSERT/UPDATE/DELETE directo.
- Administrador: SELECT filtrado por permiso de cada módulo; rol vigente se consulta en tabla privada, no `user_metadata`. `getView` de producción devuelve agregados y nombre del ganador mínimo necesario mediante endpoint validado; no expone listado de emails.
- Principal: todos los permisos y gestión de roles. La tabla privada no se lee/escribe directamente por clientes. Bootstrap inicial por migración controlada con UUID de usuario autenticado real, nunca un email sin validar ni el primer usuario registrado.
- Las políticas propuestas no dan UPDATE/INSERT/DELETE a navegador. Si se agrega actualización directa de perfil, otorgar columnas explícitas y política SELECT + UPDATE con `USING` y `WITH CHECK` de propietario; nunca incluir instagram_requirement_completed_at ni roles.
- No crear vistas que omitan RLS; cuando se usen, `WITH (security_invoker=true)` y grants mínimos.
- El helper de roles se crea por un propietario de confianza, con objetos calificados y `search_path=''`. Revocar EXECUTE por defecto a PUBLIC en funciones privilegiadas; el archivo explicita revocaciones para RPC.
- Aplicar autorización de lectura también a auditoría y métricas: ocultar botones no basta. La demo limita mutaciones en el servicio, pero expone el estado local a quien controla su navegador; no es aislamiento real.

## 5. Operaciones transaccionales y concurrencia

`sql-proposed/transactions_proposal.sql` contiene propuestas concretas para canje, giro, publicación y transición de premio. Todas son **una llamada RPC / una transacción PostgreSQL**. Nunca encadenar decremento, insert de giro e insert de premio mediante tres llamadas HTTP.

### Canje

1. Edge valida JWT, usuario y cuerpo; rate limit por usuario/IP, devuelve mensaje genérico para códigos no disponibles.
2. Bloquear wallet `FOR UPDATE`, verificar si `(user,request_id)` ya existe. Mismo request + mismo código devuelve el resultado previo; distinto payload → 409.
3. Bloquear código, comprobar activo/no revocado/fecha/uses<maxUses y campaña bajo `FOR SHARE`.
4. UNIQUE(user,code) evita doble canje. Insertar redemption con tokens/campaña snapshot; incrementar uses; ledger positivo y saldo en la misma transacción.
5. Un fallo revierte todo. No usar `ON CONFLICT DO NOTHING` y luego acreditar tokens igualmente.

### Giro

1. Bloquear `runtime` singleton → wallet → inventarios por UUID ascendente. Toda función administrativa que toque catálogo/inventario/configuración usa el mismo orden y bloquea runtime primero.
2. Consultar `(user,request_id)` bajo bloqueo y devolver el resultado previo antes de comprobar versión actual. Validar que el `expectedVersionId` visto por cliente coincide. Si cambió, 409 y pedir revisar nuevas probabilidades, sin débito.
3. Validar 6 posiciones distintas 0–5 y suma bps 10000; validar todos los segmentos con peso >0. Excluir los no elegibles, recalcular suma; si queda cero, 409 NO_ELIGIBLE_REWARDS sin débito.
4. Resolver el lote de tokens FIFO y su campaña. Reservar presupuesto al ganar, bajo el mismo bloqueo runtime. Generar `draw_bps` del lado servidor con bytes criptográficos y rechazo para evitar sesgo de módulo. El cliente no envía resultado, semilla, probabilidad o ángulo decisorio. PostgreSQL propuesto usa `extensions.gen_random_bytes` y rango uniforme 0–(suma de pesos elegibles−1).
5. Seleccionar intervalo acumulado por posición. Reservar una unidad en inventario al adjudicar. Insertar spin + snapshot y award solo si kind=prize, ledger -1, saldo -1. La animación representa el índice recibido.
6. No sortear otra vez tras un timeout. Reintentar con **la misma** clave de idempotencia hasta conocer el resultado. UI de producción guarda requestId pendiente hasta reconciliar. Para reload/múltiples dispositivos, buscar último giro por requestId y refrescar saldo; añadir cancelación/reintento visible en errores de red.

### Publicación/restauración

Guardar borrador puede tener cero en algunos segmentos; la suma válida sigue siendo 10000. Publicar valida catálogo/inventario otra vez, archiva la versión anterior y cambia runtime atómicamente. Las posiciones y snapshots de una versión publicada no se modifican ni eliminan. Restaurar copia los snapshots anteriores a un nuevo draft; los contadores de inventario no se restauran.

### Entregas

Bloquear premio, comprobar expectedRevision, propietario/permiso, fecha y transición. `UNIQUE award_id WHERE next_status='delivered'` y estado terminal evitan duplicados. Claims y auditoría en la misma transacción. Identificador de premio no autentica al ganador: verificar usuario y procedimiento presencial antes de confirmar. Cancelar requiere motivo; conservar historial. La caducidad se calcula en cada consulta/operación y una tarea programada puede materializar `expired`, sin depender de esa tarea para rechazar entregas.

### Fallos y bloqueos

Orden global coherente; ante deadlock/serialization 40P01/40001 reintento limitado en Edge con la misma requestId. No reintentar validaciones como si fueran errores transitorios. `lock_timeout` y `statement_timeout` definidos por operación, sin tiempos infinitos. Para escala futura sustituir bloqueo global por una estrategia serializable verificada; no quitarlo sin probar inventario y versiones.

## 6. Contratos API

Base futura: `/functions/v1/capi-api`. Content-Type JSON. Authorization Bearer JWT. `Idempotency-Key: UUID` en cada mutación; guardar hash canónico de payload + response para mutaciones administrativas adicionales. Never accept `actorId` del cuerpo. Respuesta `{data, revision?, requestId}`; error `{error:{code,message,fields?},requestId}`. Fechas ISO 8601 y UUID; arrays paginados cursor/limit (1–100).

| Acción actual / endpoint | Entrada de negocio | Resultado / autorización |
|---|---|---|
| `getView` / GET `/view` | section, cursor, limit | DTO State parcial + métricas derivadas; autoridad JWT, proyección mínima |
| `prize.save` / POST o PATCH `/prizes/:id` | expectedRevision, name, description, kind, icon, imagePath, color, active, capacity, expiresAt, claimDays, conditions | Prize; permiso prizes; inventory.awarded solo servidor |
| `wheel.save` / POST/PATCH `/wheel/drafts/:id` | expectedRevision, name, 6×(prizeId,probabilityBps), restoredFrom? | Version draft, snapshots creados por servidor |
| `wheel.publish` / POST `/wheel/:id/publish` | expectedRevision | Version publicada, permiso wheel |
| restaurar / POST `/wheel/:id/restore` | nombre | Nuevo draft con snapshots originales, wheel |
| `campaign.save` / POST/PATCH `/campaigns/:id` | expectedRevision, name, description, active, expiresAt | Campaign; campaigns |
| `code.create` / POST `/codes` | value? o count 1–1000, tokens 1–100, maxUses, expiry, campaignId | Lote único; codes, tasa limitada |
| `code.update` / PATCH `/codes/:id` | expectedRevision y campos permitidos | Code; no cambiar snapshot económico tras usos |
| `code.revoke` / POST `/codes/:id/revoke` | expectedRevision | Revocación permanente, usa=0 |
| exportación / GET `/codes.csv` | filtros estado/campaña/texto | CSV con escape RFC4180 + defensa de fórmula; codes |
| `code.redeem` / POST `/redemptions` | code + idempotency key | Redemption + balance, cliente con requisito completado |
| `spin` / POST `/spins` | expectedVersionId + idempotency key | Spin + Award nullable + balance; resultado servidor |
| `award.transition` / POST `/awards/:id/transition` | expectedRevision, targetStatus, reason | Award + Claim; dueño para reclamar, deliveries para entregar/cancelar |
| `instagram.complete` / POST `/instagram/complete` | Sin actor en el cuerpo; JWT | Perfil con timestamp/método link_open; idempotente, cuenta propia |
| `evidence.submit` / POST `/evidence` | kind, handle, privateStoragePath? | Pending; solo dueño, path ownership verificado |
| `evidence.review` / POST `/evidence/:id/review` | expectedRevision, approved/rejected, note | Evidence; evidence; revisión de foto opcional, sin cambiar cumplimiento |
| `role.save` / PATCH `/admin/roles/:userId` | expectedRevision, role admin/client, permissions | User mínimo; solo owner, principal protegido |
| GET `/admin/stats` | campaignId?, range? | Conteos reales del servidor, rol admin |
| GET `/admin/audit` | cursor, entidad?, rango? | Historial mínimo, owner por defecto |

`revision` de la demo se transforma a `expectedRevision` en el adaptador. No enviar el snapshot del navegador como autoridad: el servidor lo construye desde el catálogo o versión histórica validada.

### Funciones de servidor que el agente debe completar

El SQL entregado cubre cuatro transacciones críticas y el cumplimiento de Instagram; **no es una migración de backend terminado**. Implementar y probar además:

- `bootstrap_profile`: trigger controlado de Auth crea profile y token_balances=0; sin roles administrativos ni tokens iniciales. Manejar confirmación/eliminación y restricciones FK de auditoría.
- `save_prize`: runtime lock, permiso prizes, compare-and-swap revision, no reducir capacity bajo awarded, no cambiar kind en premio existente, validar URL/MIME/ruta; auditoría en la misma transacción.
- `save_wheel_draft` / `restore_wheel`: runtime lock y permiso wheel; source publicado/archivado; snapshot server-side y esquema JSON válido; validación de seis segmentos, precisión bps; no sobreescribir publicado.
- `save_campaign`: permiso, revision, campaña inactiva bloquea nuevos canjes; auditoría.
- `create_codes_batch`: permiso, validar lote antes de escribir, criptografía aleatoria (al menos 96 bits; demo usa 48 bits para IDs legibles pero NO reutilizar en producción); índice UNIQUE y reintentar colisiones de generación; lote todo-o-nada.
- `update_code`/`revoke_code`: bloqueo código, revision, campos seguros tras primer canje, revocación definitiva usa=0; no eliminar redemptions; auditoría.
- `submit_evidence`/`review_evidence`: validar propietario de archivo en Storage, tamaño/MIME, lock y revision; una pendiente por usuario y tipo; revisar fotos no cambia el requisito promocional. Abrir el enlace oficial cuenta como cumplimiento, no como verificación de seguimiento.
- `save_admin_role`: bloquear fila principal/runtime, exigir owner vigente y MFA; no editar el principal; permisos enumerados; revocar sesiones si se reduce rol sensible; auditoría.
- `view_client`/`view_admin`/`stats`/`export`: lectura proyectada y paginada; escapar CSV; no devolver códigos disponibles a clientes.
- `expire_awards`: job interno con actor de sistema documentado, registra eventos; no toca delivered/cancelled ni devuelve stock automáticamente.
- Fortalecer triggers de estados/metadatos de versiones publicadas y el rol principal contra escrituras accidentales del servidor. El SQL ya protege segmentos e historial de adjudicación; añadir tests de todos los campos inmutables.

## 7. Imágenes y Storage

- Bucket público `prize-art` solo para recursos de marca; upload/update/delete por función admin prizes. Preferir objetos inmutables y rutas `prizeId/versionUUID.webp`.
- Bucket **privado** `instagram-evidence`; cliente sube solo `auth.uid()/evidenceUUID.ext`, límite de tamaño, MIME real validado, no solo extensión. URLs firmadas cortas para dueño y reviewers con permiso evidence. No listado global.
- INSERT propio con prefijo, SELECT propio/reviewer, UPDATE/DELETE desactivados para evidencias en revisión (o función controlada). Storage upsert requiere permisos adicionales: preferir object ID nuevo.
- No guardar base64 en Postgres; la demo sí lo conserva por sencillez local (máx. 450KB/imagen, sujeto a cuota del navegador). Una imagen rechazada/cuota excedida no debe borrar datos previos.
- Retención, borrado de evidencias y aviso de privacidad deben definirse antes de abrir a usuarios reales. No guardar imágenes sensibles en logs ni snapshots de auditoría; registrar object key/hash.

## 8. Métricas reales y definiciones

El panel de producción obtiene conteos de consultas del servidor sobre estado coherente:

- Usuarios registrados: perfiles cliente; separar cuentas administrativas y eliminadas.
- Códigos creados: filas de promo_codes. Disponibles: activo, no revocado, no vencido, uses<maxUses y campaña disponible.
- Códigos canjeados: COUNT DISTINCT code_id en redemptions; canjes totales: COUNT redemptions. No confundirlos.
- Tokens entregados: SUM delta positivos; consumidos: -SUM delta negativos. Saldo debe igualar SUM movimientos por usuario.
- Giros: COUNT spins; premios: COUNT awarded_prizes (retry no cuenta).
- Reclamados: claimed_at NOT NULL, aun si ya entregado. Pendientes: pendiente/reclamado sin expirar. Entregados: delivered_at NOT NULL. Agotados: inventory.capacity NOT NULL AND awarded>=capacity.
- Campaña: códigos por campaignId, canjes y tokens por **snapshot** campaign_id de redemptions. V3.1 implementa atribución FIFO: cada giro identifica su canje fuente y campaña. No se puede escoger otra campaña desde el navegador.
- No copiar los números ilustrativos de las referencias ni mostrar variaciones porcentuales sin períodos comparables reales.

## 9. Orden de migración y conexión

1. Crear proyecto QA nuevo autorizado. Obtener URL/publishable key; secretos solo en gestor de secretos del entorno. Registrar configuración exacta de Auth, JWT, schemas expuestos y Storage.
2. Revisar changelog y documentación actual. Ejecutar CLI `--help` y `--version`; crear migración con `supabase migration new capi_core` (nombre/timestamp lo genera CLI, no esta propuesta).
3. Tras revisar DDL, crear enum/tablas/FK/CHECK/índices. `schema_proposal.sql` en transacción.
4. Aplicar RLS, grants mínimos y helpers privados; probar con anon/clientes/admin antes de semillas.
5. Agregar funciones transaccionales propuestas y completar las adicionales. Revocar EXECUTE público y conceder solo service_role. Pruebas pgTAP + adversariales.
6. Agregar bootstrap de perfiles y almacenamiento. Sembrar seis premios editables, inventario y una versión borrador; publicarla mediante función real. NO sembrar códigos demo ni identidades demo.
7. Elegir UUID real del principal y asignar rol una vez mediante operación controlada. Nunca usar el UUID de otro proyecto (p. ej. Rucaleta).
8. Implementar Edge API, JWT, MFA admin, rate limits, errores, tracing sin códigos en logs, límites de payload e idempotencia durable.
9. Implementar SupabaseService adaptador. Sustituir selector demo con Auth; solicitudes pendientes conservan requestId. Recarga/Realtime notifican cambios; en cualquier caso el servidor valida al mutar.
10. Ejecutar el recorrido de aceptación en QA, dos sesiones cliente, dos admins y carga concurrente. Revisar advisors de DB, Auth/Storage, grants y coste.
11. Solo tras validación real retirar aviso demo y habilitar público. Los recursos visuales pueden reemplazarse por nombre estable, sin rediseñar arquitectura.

## 10. Pruebas de integración obligatorias del backend futuro

1. Ejecutar recorrido UI 1–13 con cuentas Auth reales QA, stock finito y probabilidades controladas exclusivamente por semilla de prueba **solo del servidor QA**.
2. RLS: anon, cliente A/B, secundario sin permisos, secundario por permiso, owner. Probar REST directo, RPC directo, JWT falso/vencido/revocado y modificación `user_metadata`. Ningún cambio de saldo, rol, premio, probabilidad o canje cruzado.
3. 100 requests paralelos al último uso de código desde usuarios distintos: exactamente 1 ganador de canje, 1 crédito, uses=maxUses. Dos requests mismo usuario/mismo código: 1 crédito. Reintentos misma idempotency key: mismo resultado. Payload distinto: 409.
4. Dos giros simultáneos con 1 token: 1 giro/1 débito. Dos clientes contra último premio: 1 unidad reservada, el otro giro excluye ese premio y usa elegibles restantes; sin débito si ninguno queda. Publicar/desactivar/modificar stock durante giros no mezcla versiones.
5. Simular error tras cada INSERT/UPDATE de giro y canje: rollback completo; nunca balance != ledger ni spin sin su débito. Publicación falla sin archivar versión activa.
6. Doble entrega de admins distintos y replay: una transición entregado. Vencido/cancelado/entregado rechaza nueva entrega; usuario ajeno no reclama. Motivo obligatorio para cancelar.
7. Editar nombre/condiciones/imagen, publicar/restaurar: snapshots de premios y giros previos no cambian, imágenes históricas siguen iguales.
8. 0%, 100%, frontera de intervalos, suma 9999/10001, negativos, NaN, precisión excesiva, cinco/siete segmentos, prize inexistente/inactivo/agotado/vencido. Pruebas estadísticas con tolerancia justificada y sin usar como prueba única de corrección.
9. Stock NULL, cero, límite menor a awarded, cancelación sin reposición, vencimiento durante entrega; horario/zonas y límites exactos <=now.
10. Código manual duplicado por mayúsculas/espacios, generación de lote con colisión, expiración/campaña, tokens/uses/cantidad inválidos, safe edits después de canje.
11. Storage: lectura cruzada, upload fuera del prefijo, MIME falso, SVG activo, tamaño, rutas manipuladas, URL firmada vencida. Export CSV que no ejecute fórmulas.
12. Revocar permiso admin a mitad de sesión: siguiente acción bloqueada sin esperar refresh JWT. Principal no degradable; ningún secundario asigna permisos.
13. Recuperación tras timeout/reload del cliente: mismo requestId devuelve giro previo; no crear otro por una animación interrumpida. Realtime solo refresca vistas, no modifica autoridad.
14. Conciliación: sum ledger = balances; redemptions tokens = ledger code; spins = ledger spin; awarded counts = inventory.awarded salvo ajustes auditados; una config publicada.

## 11. Verificación de esta entrega y fuentes

Los tests locales de dominio y formularios se describen en `TEST_REPORT.md`. No validan SQL, JWT, RLS, Storage, redes, concurrencia distribuida ni producción. El renderizado móvil usa el runtime protegido del prototipo; prueba de navegador adicional se registra en `design-qa.md`.

Documentación oficial consultada durante preparación:

- [Supabase — Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security): RLS, ownership, views y claims.
- [Supabase — Database Functions](https://supabase.com/docs/guides/database/functions): transacciones, invoker/definer, search_path y revocación de EXECUTE.
- [Supabase — Changelog](https://supabase.com/changelog): volver a consultar al implementar. El índice `.md` no pudo recuperarse con el lector web en esta sesión; no se afirma haber verificado cambios futuros.

Esta especificación propone las decisiones de dominio y seguridad; no son garantías de un backend todavía inexistente.

## Actualización V3: acceso e Instagram

La portada siempre recibe visitantes sin sesión. Registro/login demo viven en `src/domain/demoAuth.ts`; reemplazar por Auth real, sin importar las identidades ficticias. Sesión cliente completada → ruleta; pendiente → requisitos. Administrador autorizado → panel. El selector explícito de pruebas se elimina en producción.

El enlace de Instagram abre una nueva pestaña de forma nativa, y su click dispara `instagram.complete`. En producción invocar el RPC propuesto desde Edge con actor derivado del JWT. Reintentar de forma idempotente si falla la red; reflejar Completado solo cuando persista. Nunca registrar `follower_verified=true`. El timestamp inicial no se sobrescribe. Revisar fotos no bloquea canjes ni revoca cumplimiento. Añadir pruebas por usuario, doble click concurrente, reload y login posterior; cuenta A no puede completar el perfil B.

## V3.1 — economía y disponibilidad (prioridad sobre V3)

Orden SQL obligatorio: `schema_proposal.sql` → `rewards_proposal.sql` → `transactions_proposal.sql`. Ninguno ejecutado. El agente debe completar las operaciones administrativas faltantes y probarlos en un proyecto CAPI independiente. No usar RUCALETA.

`src/domain/rewards.ts` implementa elegibilidad, atribución FIFO, día comercial America/Mexico_City y métricas. Los precios se guardan en centavos enteros MXN. Los valores iniciales de costos son cero (datos ficticios); el administrador debe cargar costos reales antes de cualquier producción. Límites vacíos significan ilimitado, cero deshabilita asignaciones materiales que excedan ese límite.

Tablas económicas privadas en el nuevo SQL:
- `reward_policies`: PK/FK prize_id, cost_cents bigint>=0, daily_limit y campaign_limit integer>=0 nullable.
- `campaign_budgets`: PK/FK campaign_id, budget_cents/daily_budget_cents bigint>=0 nullable, max_awards integer>=0 nullable.
- `category_limits`: PK campaign_id+category, max_awards integer>=0.
- `reward_settings`: singleton, daily_budget_cents global nullable.
- `award_costs`: PK/FK award_id, campaign_id FK nullable, prize_id FK, category y cost_cents históricos, created_at UTC. INSERT inmutable por adjudicación; crear trigger que rechace UPDATE/DELETE y verificarlo antes de producción.
- `spins.redemption_id` y `spins.campaign_id` atan el giro al lote original. Bloquear wallet y elegir el primer canje con tokens sin consumir por created_at,id. No aceptar fuente/campaña del cliente.

La reserva se produce al adjudicar, incluso si queda pendiente. Entregar no vuelve a consumir presupuesto. Cancelar/vencer no libera costo ni stock automáticamente. Las métricas distinguen costo comprometido de costo entregado; promedio = comprometido / giros totales, incluyendo participaciones sin premio. El límite diario del premio aplica tanto a adjudicaciones como a entregas en el día local. Las entregas atrasadas no pueden exceder el límite diario vigente.

Los RPC de giro/publicación/entrega y TODAS las escrituras de costos, límites, campañas y estado deben bloquear primero `runtime`, después wallet cuando aplique, después filas de inventario ordenadas. El bloqueo único evita que dos usuarios consuman el mismo presupuesto. Una operación fallida revierte costo, inventario, giro y token juntos. Para mayor escala puede sustituirse por contadores/bloqueos por día/campaña, solo tras pruebas equivalentes de concurrencia.

Contratos nuevos: `settings.save {dailyBudgetCents}` requiere campaigns; `prize.save` añade costCents/category/dailyLimit/campaignLimit/startsAt/featured/retired; `prize.retire {id,revision}` requiere prizes; `campaign.save` añade budgetCents/dailyBudgetCents/maxAwards/categoryLimits/startsAt. Todos auditan antes/después en la misma transacción. Validar enteros no negativos, fechas ordenadas y costo=0 para retry. Insertar reward_policies al crear cada premio, incluso retry. Administradores calculan probabilidad efectiva como weight/suma_elegibles; cliente nunca recibe costos, presupuestos ni pesos por API.

RLS no oculta columnas: el SQL restringe SELECT de wheel_segments a columnas seguras para authenticated; la administración accede a pesos mediante Edge autorizado. Las tablas económicas privadas no tienen grants/policies para clientes. Snapshots públicos NO incluyen costos ni pesos. El adaptador debe solicitar columnas explícitas, no `select('*')`. No devolver draw_bps o datos internos al cliente por endpoints; transformar respuesta RPC a DTO mínimo {id,segment,snapshot,awardId,createdAt,balance}. MockService filtra proyecciones y respuestas, pero el almacenamiento local sigue siendo inspeccionable y no proporciona seguridad real.

Pruebas adicionales obligatorias: dos usuarios contra último centavo, categoría agotada, presupuesto global entre campañas, costo cero, límite cero, retiro/reactivación, cambio de día de México, no elegibles conserva token, fallback retry habilitado/deshabilitado, FIFO en mezcla de códigos, costo histórico tras editar, entrega sin doble cargo y SELECT/REST sin acceso a pesos/costos. Para datos históricos reales existentes habría que hacer backfill FIFO/costos mediante migración auditada, nunca asumir costo cero; la compatibilidad local V3 usa cero solo para datos simulados antiguos.
