import {MockService,MemoryStorage,permissions,type State} from '../src/domain/service.ts';

// Only this authenticated server endpoint can read/write the aggregate.
// PostgreSQL compare-and-swap commits all balances, inventory and results together.
const URL=Deno.env.get('SUPABASE_URL')!;
const SECRET=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Cache-Control':'no-store'};
const response=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json'}});
async function db(path:string,method='GET',body?:unknown){
 const r=await fetch(`${URL}/rest/v1/${path}`,{method,headers:{apikey:SECRET,Authorization:`Bearer ${SECRET}`,'Content-Type':'application/json',Prefer:'return=representation'},body:body===undefined?undefined:JSON.stringify(body)});
 if(!r.ok)throw new Error('No se pudo guardar la operación. Inténtalo de nuevo.');return r.status===204?null:await r.json();
}
const allowed=new Set(['view','prize.save','prize.retire','wheel.save','wheel.publish','settings.save','campaign.save','code.create','code.update','code.revoke','code.redeem','spin','award.transition','evidence.submit','evidence.review','role.save','instagram.complete']);
Deno.serve(async(req:Request)=>{
 if(req.method==='OPTIONS')return new Response(null,{headers:cors});
 if(req.method!=='POST')return response({error:'Método no permitido.'},405);
 try{
  const raw=await req.text();if(raw.length>750000)return response({error:'Solicitud demasiado grande.'},413);
  const body=JSON.parse(raw);const action=body.action;
  if(!allowed.has(action))return response({error:'Operación no permitida.'},403);
  let identity:any=null;
  const bearer=req.headers.get('Authorization');
  if(bearer){const auth=await fetch(`${URL}/auth/v1/user`,{headers:{apikey:SECRET,Authorization:bearer}});if(!auth.ok)return response({error:'La sesión venció. Inicia sesión de nuevo.'},401);identity=await auth.json();if(!identity.email_confirmed_at)return response({error:'Confirma tu correo antes de continuar.'},403);}
  if(!identity&&action!=='view')return response({error:'Inicia sesión para continuar.'},401);
  const actor=identity?.id??'guest';
  if(identity){
   const encoded=bearer!.split('.')[1].replaceAll('-','+').replaceAll('_','/');
   const claims=JSON.parse(atob(encoded.padEnd(Math.ceil(encoded.length/4)*4,'=')));
   if(!claims.session_id||!await db('rpc/capi_session_active','POST',{p_actor:actor,p_session:claims.session_id}))return response({error:'La sesión fue cerrada. Inicia sesión de nuevo.'},401);
  }
  if(identity){const ok=await db('rpc/capi_rate_limit','POST',{p_actor:actor});if(!ok)return response({error:'Demasiadas solicitudes. Espera un minuto.'},429);}
  const [owner]=await db('capi_owner?select=id,user_id,email&id=eq.1');
  if(identity&&!owner.user_id&&identity.email?.toLowerCase()===owner.email){
   await db(`capi_owner?id=eq.1&user_id=is.null`,'PATCH',{user_id:identity.id});
   const [bound]=await db('capi_owner?select=user_id&id=eq.1');owner.user_id=bound.user_id;
  }
  // actorId from the request is deliberately ignored. No demo actions are accepted.
  for(let attempt=0;attempt<5;attempt++){
   const [row]=await db('capi_state?select=version,document&id=eq.1');
   const storage=new MemoryStorage();const state=row.document as State;
   let changed=false;
   if(identity){let user=state.users.find(u=>u.id===actor);
    if(!user){user={id:actor,name:String(identity.user_metadata?.name||'Cliente CAPI').slice(0,50),role:'client',permissions:[],verified:false,createdAt:new Date().toISOString()};state.users.push(user);changed=true;}
    if(actor===owner.user_id&&user.role!=='owner'){user.role='owner';user.permissions=[...permissions];changed=true;}
   }
   storage.save(state);const service=new MockService(storage);
   if(action==='code.create'||action==='code.update'){
    if(Number(body.payload?.maxUses)!==1)return response({error:'Los códigos de compra son de un solo uso.'},400);
   }
   const result=action==='view'?await service.getView(actor):await service.execute(actor,action,body.payload??{});
   if(action!=='view'||changed){const saved=await db(`capi_state?id=eq.1&version=eq.${row.version}`,'PATCH',{version:row.version+1,document:storage.load()});if(!saved.length)continue;}
   if(action==='spin'){
    const spin=result as any;const version=storage.load()!.versions.find(v=>v.id===spin.versionId)!;
    const presentation={...version,segments:version.segments.map(seg=>{const {costCents,dailyLimit,campaignLimit,...snapshot}=seg.snapshot;return {prizeId:seg.prizeId,probability:0,snapshot}})};
    return response({data:{...spin,presentation}});
   }
   return response({data:result});
  }
  return response({error:'Hay otra operación en curso. Vuelve a intentar con la misma solicitud.'},409);
 }catch(e){return response({error:e instanceof Error?e.message:'No se pudo completar la operación.'},400);}
});
