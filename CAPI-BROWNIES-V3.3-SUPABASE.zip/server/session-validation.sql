grant select on auth.sessions to service_role;
create function public.capi_session_active(p_actor uuid,p_session uuid) returns boolean
language sql stable security invoker set search_path='' as $$
 select exists(select 1 from auth.sessions where id=p_session and user_id=p_actor and (not_after is null or not_after>now()));
$$;
revoke all on function public.capi_session_active(uuid,uuid) from public,anon,authenticated;
grant execute on function public.capi_session_active(uuid,uuid) to service_role;
