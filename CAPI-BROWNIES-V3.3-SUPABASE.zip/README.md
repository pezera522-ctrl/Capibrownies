# CAPI BROWNIES — V3.3 conectada a Supabase

Proyecto: llfltkdrcrekhllmzfsw. Código existente conservado; no se migran datos de demostración.

- Acceso con Supabase Auth; correo confirmado obligatorio. El propietario queda vinculado al UUID verificado de leonelmtz522@gmail.com, nunca al primer registro.
- API capi-api: permisos, canje de un solo uso, saldos, premios, inventario y presupuestos se ejecutan en servidor. Operaciones se guardan juntas mediante comparación atómica de versión PostgreSQL.
- Ruleta de 3–20 segmentos. Administración permite contar giros o códigos canjeados por campaña para premios destacados. En modo compras, cada N.º código habilita un destacado solo en su primer giro, si tiene peso, inventario y presupuesto. Los demás giros usan premios ordinarios. El contador no aparece al cliente; las reglas explican que la selección no es enteramente aleatoria.
- Campaña y premios materiales iniciales pausados. Configurar costos, presupuesto, existencias y condiciones antes de activar. No hay códigos demo en el servidor.

## Abrir

Node.js 24. Dentro de esta carpeta: npm start (compilación incluida, sin instalar dependencias).
Para desarrollar: npm ci y npm run dev. Para compilar: npm run build.
Para demo aislada: VITE_CAPI_MODE=demo npm run dev. Nunca use su selector de cuentas para seguridad real.

## Verificación y pendientes

23 pruebas de dominio previas, 2 nuevas de cadencia y 4 de API con base simulada aprobadas. 8 pruebas de interfaz aprobadas (7 en primera pasada y 1 corregida/repetida). 3 comprobaciones de acceso contra Supabase real, 4 de hosting y 1 del servidor estático aprobadas. Compilación e integridad del runtime aprobadas.
No se ha completado un registro confirmado, canje y entrega de extremo a extremo en el proyecto remoto. Safari físico pendiente.
Antes del lanzamiento: registrar/verificar el correo propietario; configurar URL pública de Auth y envío de correos (SMTP); comprobar recuperación de contraseña y recorrido real; fijar condiciones promocionales y tratamiento de datos. No se afirma que esté lista para premios reales.

## Persistencia inicial

capi_state contiene un agregado JSONB privado: mantiene intacto el motor validado y permite un commit atómico de toda la operación. No es la normalización de tablas propuesta originalmente. Las escrituras de todas las campañas comparten un punto de concurrencia; medir carga y migrar a tablas por entidad/paginación/Storage antes de crecimiento significativo. La auditoría es de aplicación, no un registro externo inalterable.
server/bootstrap.sql y server/session-validation.sql reflejan migraciones YA aplicadas. No volver a ejecutarlas. server/capi-api.ts es la función desplegada; depende de src/domain/service.ts y rewards.ts. Secretos de servidor solo en Supabase.
