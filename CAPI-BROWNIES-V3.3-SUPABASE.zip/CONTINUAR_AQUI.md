# Continuar CAPI BROWNIES — 24 octubre 2026

- Conservar V3.3; proyecto Supabase definitivo llfltkdrcrekhllmzfsw en organización tqxuejtthihfmerbizex.
- Aplicadas migraciones capi_secure_state_owner_and_rate_limit y capi_validate_active_auth_session. Edge Function capi-api activa; último despliegue debe incluir server/capi-api.ts + src/domain/service.ts + src/domain/rewards.ts.
- Tablas capi_state, capi_owner y capi_rate_windows con RLS y sin grants a anon/authenticated. Servicio usa credencial privada del entorno, Auth getUser y sesión vigente. Mutaciones compare-and-swap PostgreSQL; no fiarse de actorId del cliente.
- Correo reservado propietario: leonelmtz522@gmail.com. Se vincula solo tras confirmación de correo; aún no hay cuentas en Auth ni propietario vinculado en la última consulta. No crear contraseña ni marcar el correo como confirmado por cuenta del usuario.
- Frontend live por defecto (test o VITE_CAPI_MODE=demo usan MockService). No permite selector administrativo en live. Auth registro/login/logout/recuperación implementados.
- Cambios 3–20 segmentos y cadencia por compras/canjes o giros, presupuestos y existencia; null desactiva. Política pública no promete aleatoriedad total; no expone contador económico.
- Pruebas: 29 dominio/API locales, 8 UI, 3 acceso remoto, 4 hosting, 1 estático aprobadas. No equivalen a prueba remota con usuario confirmado ni Safari físico.
- Pendiente obligatorio: URL pública en Supabase Auth, correo/SMTP y recuperación, registrar y verificar dueño, recorrido remoto cliente/admin/concurrencia con cuentas reales de QA, costos/stock/budgets y activación de campañas. Todo material arranca pausado, sin códigos de prueba.
- Limitación arquitectura: agregado privado JSONB atómico, NO todas las tablas normalizadas originalmente previstas. No anunciar lanzamiento público todavía. No modificar otros proyectos.
