-- V3.1 proposal. Run AFTER schema_proposal.sql and BEFORE transactions_proposal.sql.
-- Not applied or integration-tested. Use only a new independent CAPI project.
begin;
alter table public.prizes add column starts_at timestamptz, add column category text not null default 'General', add column featured boolean not null default false, add column retired boolean not null default false;
alter table public.prizes add check(starts_at is null or expires_at is null or starts_at<expires_at);
alter table public.campaigns add column starts_at timestamptz;
alter table public.campaigns add check(starts_at is null or expires_at is null or starts_at<expires_at);
alter table public.spins add column redemption_id uuid references public.code_redemptions(id),add column campaign_id uuid references public.campaigns(id);
create index spins_funding on public.spins(redemption_id);
create index redemption_fifo on public.code_redemptions(user_id,created_at,id);
create table capi_private.reward_policies (
 prize_id uuid primary key references public.prizes(id),cost_cents bigint not null default 0 check(cost_cents>=0),
 daily_limit integer check(daily_limit>=0),campaign_limit integer check(campaign_limit>=0)
);
insert into capi_private.reward_policies(prize_id) select id from public.prizes;
create table capi_private.campaign_budgets (
 campaign_id uuid primary key references public.campaigns(id),budget_cents bigint check(budget_cents>=0),
 daily_budget_cents bigint check(daily_budget_cents>=0),max_awards integer check(max_awards>=0)
);
create table capi_private.category_limits (
 campaign_id uuid references public.campaigns(id), category text check(length(category) between 1 and 40),max_awards integer not null check(max_awards>=0),primary key(campaign_id,category)
);
create table capi_private.reward_settings (singleton boolean primary key default true check(singleton),daily_budget_cents bigint check(daily_budget_cents>=0));
insert into capi_private.reward_settings values(true,null);
-- Reservations are never released by delivery, cancellation or expiration.
create table capi_private.award_costs (
 award_id uuid primary key references public.awarded_prizes(id),campaign_id uuid references public.campaigns(id),prize_id uuid not null references public.prizes(id),category text not null,
 cost_cents bigint not null check(cost_cents>=0),created_at timestamptz not null default now()
);
create index award_cost_campaign on capi_private.award_costs(campaign_id,created_at);
create index award_cost_prize on capi_private.award_costs(prize_id,created_at);
create index award_cost_day on capi_private.award_costs(created_at);
create index delivered_prize_day on public.awarded_prizes(prize_id,delivered_at) where delivered_at is not null;
do $$declare t text;begin foreach t in array array['reward_policies','campaign_budgets','category_limits','reward_settings','award_costs'] loop
 execute format('alter table capi_private.%I enable row level security',t);
 execute format('revoke all on capi_private.%I from public,anon,authenticated',t);
 execute format('grant all on capi_private.%I to service_role',t);
end loop;end$$;
-- Published base weights are admin-only; clients request these explicit safe columns.
revoke select on public.wheel_segments from authenticated;
grant select(version_id,position,prize_id,prize_snapshot) on public.wheel_segments to authenticated;
create function capi_private.random_range(p_upper integer) returns integer language plpgsql volatile set search_path='' as $$
declare b bytea;n bigint;ceiling bigint;begin
 if p_upper<1 or p_upper>10000 then raise exception 'INVALID_RANDOM_RANGE';end if;
 ceiling:=floor(4294967296::numeric/p_upper)::bigint*p_upper;
 loop b:=extensions.gen_random_bytes(4);n:=get_byte(b,0)::bigint*16777216+get_byte(b,1)::bigint*65536+get_byte(b,2)::bigint*256+get_byte(b,3);exit when n<ceiling;end loop;
 return (n%p_upper)::integer;
end$$;
-- Caller holds runtime lock. Economic policies and award_costs never enter public snapshots.
create function capi_private.eligible_pool(p_version uuid,p_campaign uuid)
returns table(position smallint,weight integer) language sql stable security invoker set search_path='' as $$
 with today as(select date_trunc('day',now() at time zone 'America/Mexico_City') at time zone 'America/Mexico_City' as start_at),
 candidates as(select s.position,s.probability_bps,p.*,rp.cost_cents,rp.daily_limit,rp.campaign_limit,i.capacity,i.awarded
 from public.wheel_segments s join public.prizes p on p.id=s.prize_id join public.prize_inventory i on i.prize_id=p.id join capi_private.reward_policies rp on rp.prize_id=p.id
 where s.version_id=p_version and s.probability_bps>0 and p.active and not p.retired and (p.starts_at is null or p.starts_at<=now()) and (p.expires_at is null or p.expires_at>now()) and ((s.prize_snapshot->>'expiresAt') is null or (s.prize_snapshot->>'expiresAt')::timestamptz>now()))
 select p.position,p.probability_bps from candidates p cross join today d
 left join capi_private.campaign_budgets cb on cb.campaign_id=p_campaign
 left join capi_private.category_limits cl on cl.campaign_id=p_campaign and cl.category=p.category
 cross join capi_private.reward_settings g
 where (p_campaign is null or exists(select 1 from public.campaigns c where c.id=p_campaign and c.active and (c.starts_at is null or c.starts_at<=now()) and (c.expires_at is null or c.expires_at>now())))
 and (p.kind='retry' or (
 (p.capacity is null or p.awarded<p.capacity)
 and (p.daily_limit is null or (select count(*) from capi_private.award_costs a where a.prize_id=p.id and a.created_at>=d.start_at)<p.daily_limit)
 and (p.campaign_limit is null or (select count(*) from capi_private.award_costs a where a.prize_id=p.id and a.campaign_id is not distinct from p_campaign)<p.campaign_limit)
 and (cb.max_awards is null or (select count(*) from capi_private.award_costs a where a.campaign_id=p_campaign)<cb.max_awards)
 and (cl.max_awards is null or (select count(*) from capi_private.award_costs a where a.campaign_id=p_campaign and a.category=p.category)<cl.max_awards)
 and (g.daily_budget_cents is null or (select coalesce(sum(a.cost_cents),0) from capi_private.award_costs a where a.created_at>=d.start_at)+p.cost_cents<=g.daily_budget_cents)
 and (cb.daily_budget_cents is null or (select coalesce(sum(a.cost_cents),0) from capi_private.award_costs a where a.campaign_id=p_campaign and a.created_at>=d.start_at)+p.cost_cents<=cb.daily_budget_cents)
 and (cb.budget_cents is null or (select coalesce(sum(a.cost_cents),0) from capi_private.award_costs a where a.campaign_id=p_campaign)+p.cost_cents<=cb.budget_cents)
 ));
$$;
revoke all on function capi_private.random_range(integer),capi_private.eligible_pool(uuid,uuid) from public,anon,authenticated;
grant execute on function capi_private.random_range(integer),capi_private.eligible_pool(uuid,uuid) to service_role;
commit;
