-- CAPI BROWNIES: proposed schema only. NOT applied or production-validated.
-- Future agent: use `supabase migration new capi_core` and review the generated file.
-- Assumes Supabase auth.users and pgcrypto in schema extensions.
begin;
create schema if not exists capi_private;
create extension if not exists pgcrypto with schema extensions;
create type public.capi_role as enum ('owner','admin','client');
create type public.capi_award_status as enum ('pending','claimed','delivered','expired','cancelled');
create type public.capi_version_status as enum ('draft','published','archived');

create table public.profiles (
 id uuid primary key references auth.users(id) on delete restrict,
 display_name text not null check(length(display_name) between 1 and 80),
 instagram_requirement_completed_at timestamptz,
 instagram_completion_method text check(instagram_completion_method='link_open'),
 check ((instagram_requirement_completed_at is null)=(instagram_completion_method is null)), created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table capi_private.admin_roles (
 user_id uuid primary key references public.profiles(id) on delete restrict,
 role public.capi_role not null check(role in ('owner','admin')),
 permissions text[] not null default '{}', revision bigint not null default 1,
 granted_by uuid references public.profiles(id), updated_at timestamptz not null default now(),
 check(permissions <@ array['prizes','wheel','codes','deliveries','evidence','campaigns']::text[])
);
create unique index one_principal_admin on capi_private.admin_roles(role) where role='owner';
create table public.prizes (
 id uuid primary key default gen_random_uuid(), name text not null check(length(name) between 1 and 60),
 description text not null check(length(description) between 1 and 500),
 kind text not null check(kind in ('prize','retry')), icon text not null,
 image_path text, color text not null check(color ~ '^#[0-9a-fA-F]{6}$'),
 active boolean not null default true, expires_at timestamptz,
 claim_days integer not null check(claim_days between 1 and 365),
 conditions text not null check(length(conditions) between 1 and 1000),
 revision bigint not null default 1, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.prize_inventory (
 prize_id uuid primary key references public.prizes(id), capacity bigint check(capacity>=0),
 awarded bigint not null default 0 check(awarded>=0), revision bigint not null default 1,
 check(capacity is null or awarded<=capacity)
);
create table public.campaigns (
 id uuid primary key default gen_random_uuid(), name text not null check(length(name) between 1 and 80),
 description text not null default '', active boolean not null default true,
 expires_at timestamptz, revision bigint not null default 1, created_at timestamptz not null default now()
);
create table public.wheel_versions (
 id uuid primary key default gen_random_uuid(), version bigint generated always as identity unique,
 name text not null check(length(name) between 1 and 80), status public.capi_version_status not null default 'draft',
 restored_from uuid references public.wheel_versions(id), created_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now(), published_at timestamptz,
 revision bigint not null default 1,
 check((status='draft' and published_at is null) or (status<>'draft' and published_at is not null))
);
create unique index one_published_wheel on public.wheel_versions(status) where status='published';
create table public.wheel_segments (
 version_id uuid not null references public.wheel_versions(id),
 position smallint not null check(position between 0 and 5),
 prize_id uuid not null references public.prizes(id),
 probability_bps integer not null check(probability_bps between 0 and 10000),
 -- Immutable copy: id,name,description,kind,icon,image,color,conditions,claimDays,expiresAt,revision.
 prize_snapshot jsonb not null check(jsonb_typeof(prize_snapshot)='object'),
 primary key(version_id,position)
);
create table capi_private.runtime (
 singleton boolean primary key default true check(singleton),
 published_version_id uuid references public.wheel_versions(id), revision bigint not null default 1
);
insert into capi_private.runtime(singleton) values(true);
create table public.promo_codes (
 id uuid primary key default gen_random_uuid(),
 code text not null unique check(code ~ '^[A-Z0-9-]{4,40}$'),
 campaign_id uuid references public.campaigns(id), tokens integer not null check(tokens between 1 and 100),
 max_uses integer not null check(max_uses between 1 and 1000000), uses integer not null default 0 check(uses>=0),
 active boolean not null default true, revoked_at timestamptz, expires_at timestamptz,
 created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(),
 revision bigint not null default 1, check(uses<=max_uses), check(revoked_at is null or uses=0)
);
create table public.token_balances (
 user_id uuid primary key references public.profiles(id), balance bigint not null default 0 check(balance>=0),
 revision bigint not null default 1, updated_at timestamptz not null default now()
);
create table public.code_redemptions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
 code_id uuid not null references public.promo_codes(id), campaign_id uuid references public.campaigns(id),
 code_snapshot text not null, tokens_granted integer not null check(tokens_granted between 1 and 100),
 request_id uuid not null, created_at timestamptz not null default now(),
 unique(user_id,code_id),unique(user_id,request_id)
);
create table public.spins (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
 request_id uuid not null, version_id uuid not null references public.wheel_versions(id),
 segment_position smallint not null, prize_snapshot jsonb not null,
 -- Server-generated sample; not accepted from client.
 draw_bps integer not null check(draw_bps between 0 and 9999),
 created_at timestamptz not null default now(), unique(user_id,request_id),
 foreign key(version_id,segment_position) references public.wheel_segments(version_id,position)
);
create table public.token_movements (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
 delta integer not null check(delta<>0), kind text not null check(kind in ('code','spin')),
 redemption_id uuid unique references public.code_redemptions(id), spin_id uuid unique references public.spins(id),
 created_at timestamptz not null default now(),
 check((kind='code' and delta>0 and redemption_id is not null and spin_id is null)
 or (kind='spin' and delta=-1 and spin_id is not null and redemption_id is null))
);
create table public.awarded_prizes (
 id uuid primary key default gen_random_uuid(), reference uuid not null unique default gen_random_uuid(),
 user_id uuid not null references public.profiles(id), spin_id uuid not null unique references public.spins(id),
 prize_id uuid not null references public.prizes(id), version_id uuid not null references public.wheel_versions(id),
 prize_snapshot jsonb not null, original_conditions text not null,
 created_at timestamptz not null default now(), expires_at timestamptz not null,
 status public.capi_award_status not null default 'pending',
 claimed_at timestamptz, delivered_at timestamptz, delivered_by uuid references public.profiles(id),
 cancelled_at timestamptz, cancelled_by uuid references public.profiles(id), cancellation_reason text,
 revision bigint not null default 1,check(expires_at>created_at),
 check((status='delivered')=(delivered_at is not null)),
 check(status<>'cancelled' or (cancelled_at is not null and length(cancellation_reason)>0))
);
create table public.claim_events (
 id uuid primary key default gen_random_uuid(), award_id uuid not null references public.awarded_prizes(id),
 actor_id uuid not null references public.profiles(id), previous_status public.capi_award_status not null,
 next_status public.capi_award_status not null, note text not null default '',
 request_id uuid not null,created_at timestamptz not null default now(), unique(actor_id,request_id)
);
create unique index award_delivered_once on public.claim_events(award_id) where next_status='delivered';
create table public.instagram_evidence (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
 kind text not null check(kind in ('follow','photo')), instagram_handle text not null check(instagram_handle ~ '^@?[A-Za-z0-9._]{1,30}$'),
 storage_path text, status text not null default 'pending' check(status in ('pending','approved','rejected')),
 review_note text, reviewed_by uuid references public.profiles(id), reviewed_at timestamptz,
 created_at timestamptz not null default now(),check(kind<>'photo' or storage_path is not null)
);
create unique index one_pending_evidence_kind on public.instagram_evidence(user_id,kind) where status='pending';
create table capi_private.admin_audit (
 id bigint generated always as identity primary key, actor_id uuid not null references public.profiles(id),
 action text not null,entity_type text not null,entity_id uuid, before_data jsonb,after_data jsonb,
 request_id uuid not null,created_at timestamptz not null default now()
);

create index codes_campaign on public.promo_codes(campaign_id);
create index codes_active_expiry on public.promo_codes(expires_at) where active and revoked_at is null;
create index redemptions_code_created on public.code_redemptions(code_id,created_at desc);
create index redemptions_campaign on public.code_redemptions(campaign_id,created_at desc);
create index ledger_user_created on public.token_movements(user_id,created_at desc);
create index spins_user_created on public.spins(user_id,created_at desc);
create index awarded_user_created on public.awarded_prizes(user_id,created_at desc);
create index awarded_prize_status on public.awarded_prizes(prize_id,status);
create index awarded_pending_expiry on public.awarded_prizes(expires_at) where status in ('pending','claimed');
create index claims_award_created on public.claim_events(award_id,created_at desc);
create index evidence_user on public.instagram_evidence(user_id,created_at desc);
create index audit_actor on capi_private.admin_audit(actor_id,created_at desc);

-- Policy-only helper. No user-controllable actor parameter; roles are read live.
create function capi_private.has_permission(p_permission text) returns boolean
language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and exists(select 1 from capi_private.admin_roles
 where user_id=auth.uid() and (role='owner' or (role='admin' and p_permission=any(permissions))));
$$;
revoke all on schema capi_private from public,anon,authenticated;
grant usage on schema capi_private to authenticated,service_role;
revoke all on function capi_private.has_permission(text) from public,anon;
grant execute on function capi_private.has_permission(text) to authenticated,service_role;

-- No direct browser writes, even for administrators. Edge server owns the write API.
do $$declare t text;begin
 foreach t in array array['profiles','prizes','prize_inventory','campaigns','wheel_versions','wheel_segments','promo_codes','token_balances','code_redemptions','spins','token_movements','awarded_prizes','claim_events','instagram_evidence'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('revoke all on public.%I from anon,authenticated',t);
 execute format('grant select on public.%I to authenticated',t);
 execute format('grant all on public.%I to service_role',t);
 end loop;
end $$;
alter table capi_private.admin_roles enable row level security;
alter table capi_private.admin_audit enable row level security;
alter table capi_private.runtime enable row level security;
grant all on all tables in schema capi_private to service_role;
grant usage,select on all sequences in schema capi_private to service_role;
grant usage,select on all sequences in schema public to service_role;
create policy own_profile on public.profiles for select to authenticated using(id=(select auth.uid()));
create policy published_prizes on public.prizes for select to authenticated using(active or (select capi_private.has_permission('prizes')));
create policy inventory_admin on public.prize_inventory for select to authenticated using((select capi_private.has_permission('prizes')));
create policy campaigns_admin on public.campaigns for select to authenticated using((select capi_private.has_permission('campaigns')));
create policy versions_visible on public.wheel_versions for select to authenticated using(status='published' or (select capi_private.has_permission('wheel')));
create policy segments_visible on public.wheel_segments for select to authenticated using(exists(select 1 from public.wheel_versions v where v.id=version_id and (v.status='published' or (select capi_private.has_permission('wheel')))));
create policy codes_admin on public.promo_codes for select to authenticated using((select capi_private.has_permission('codes')));
create policy own_balance on public.token_balances for select to authenticated using(user_id=(select auth.uid()));
create policy redemptions_visible on public.code_redemptions for select to authenticated using(user_id=(select auth.uid()) or (select capi_private.has_permission('codes')));
create policy own_spins on public.spins for select to authenticated using(user_id=(select auth.uid()));
create policy own_movements on public.token_movements for select to authenticated using(user_id=(select auth.uid()));
create policy awards_visible on public.awarded_prizes for select to authenticated using(user_id=(select auth.uid()) or (select capi_private.has_permission('deliveries')));
create policy claims_visible on public.claim_events for select to authenticated using(exists(select 1 from public.awarded_prizes a where a.id=award_id and (a.user_id=(select auth.uid()) or (select capi_private.has_permission('deliveries')))));
create policy evidence_visible on public.instagram_evidence for select to authenticated using(user_id=(select auth.uid()) or (select capi_private.has_permission('evidence')));

-- Immutable history, including for accidental writes from trusted server code.
create function capi_private.reject_history_mutation() returns trigger language plpgsql set search_path='' as $$begin raise exception 'HISTORY_IMMUTABLE';end$$;
create trigger immutable_spins before update or delete on public.spins for each row execute function capi_private.reject_history_mutation();
create trigger immutable_redemptions before update or delete on public.code_redemptions for each row execute function capi_private.reject_history_mutation();
create trigger immutable_ledger before update or delete on public.token_movements for each row execute function capi_private.reject_history_mutation();
create trigger immutable_claims before update or delete on public.claim_events for each row execute function capi_private.reject_history_mutation();
create trigger immutable_audit before update or delete on capi_private.admin_audit for each row execute function capi_private.reject_history_mutation();
create function capi_private.protect_segments() returns trigger language plpgsql set search_path='' as $$
 declare v uuid;begin v:=case when TG_OP='DELETE' then old.version_id else new.version_id end;
 if exists(select 1 from public.wheel_versions where id=v and status<>'draft') or
 (TG_OP='UPDATE' and exists(select 1 from public.wheel_versions where id=old.version_id and status<>'draft')) then raise exception 'PUBLISHED_VERSION_IMMUTABLE'; end if;
 if TG_OP='DELETE' then return old; end if;return new;end$$;
create trigger protect_wheel_segments before insert or update or delete on public.wheel_segments for each row execute function capi_private.protect_segments();
create function capi_private.protect_award_snapshot() returns trigger language plpgsql set search_path='' as $$begin
 if (new.user_id,new.spin_id,new.prize_id,new.version_id,new.prize_snapshot,new.original_conditions,new.created_at,new.expires_at,new.reference) is distinct from
 (old.user_id,old.spin_id,old.prize_id,old.version_id,old.prize_snapshot,old.original_conditions,old.created_at,old.expires_at,old.reference) then raise exception 'AWARD_SNAPSHOT_IMMUTABLE';end if;return new;end$$;
create trigger protect_award before update on public.awarded_prizes for each row execute function capi_private.protect_award_snapshot();
revoke all on all functions in schema capi_private from public,anon;
commit;
