-- Proposed SQL only. Requires schema_proposal.sql then rewards_proposal.sql (V3.1). Review + integration tests before use.
-- These PUBLIC rpc entry points are executable ONLY by service_role in trusted Edge Functions.
-- Edge verifies the real JWT with auth.getUser(), derives p_actor, then calls RPC.
-- Never trust actorId, role, result, balance or random seed supplied by the browser.
begin;
create function capi_private.require_permission(p_actor uuid,p_permission text) returns void
language plpgsql security invoker set search_path='' as $$begin
 if p_actor is null or not exists(select 1 from capi_private.admin_roles where user_id=p_actor and (role='owner' or p_permission=any(permissions))) then raise exception 'FORBIDDEN';end if;
end$$;
create function capi_private.random_bps() returns integer language plpgsql volatile set search_path='' as $$
 declare b bytea;n bigint;begin loop b:=extensions.gen_random_bytes(4);n:=get_byte(b,0)::bigint*16777216+get_byte(b,1)::bigint*65536+get_byte(b,2)::bigint*256+get_byte(b,3);exit when n<4294960000;end loop;return (n%10000)::integer;end$$;

-- Promotional completion records opening the link, never actual follower verification.
create function public.capi_server_complete_instagram(p_actor uuid) returns jsonb
language plpgsql security invoker set search_path='' as $$
declare p public.profiles;begin
 if p_actor is null then raise exception 'UNAUTHORIZED';end if;
 if exists(select 1 from capi_private.admin_roles where user_id=p_actor) then raise exception 'CLIENT_REQUIRED';end if;
 select * into p from public.profiles where id=p_actor for update;
 if not found then raise exception 'PROFILE_NOT_READY';end if;
 if p.instagram_requirement_completed_at is null then
 update public.profiles set instagram_requirement_completed_at=now(),instagram_completion_method='link_open',updated_at=now() where id=p_actor returning * into p;
 end if;
 return to_jsonb(p);
end$$;
revoke all on function public.capi_server_complete_instagram(uuid) from public,anon,authenticated;
grant execute on function public.capi_server_complete_instagram(uuid) to service_role;

create function public.capi_server_redeem(p_actor uuid,p_code text,p_request uuid) returns jsonb
language plpgsql security invoker set search_path='' as $$
 declare c public.promo_codes;r public.code_redemptions;available bigint;begin
 if p_actor is null or p_request is null then raise exception 'UNAUTHORIZED';end if;
 if not exists(select 1 from public.profiles where id=p_actor and instagram_requirement_completed_at is not null) then raise exception 'PARTICIPATION_REQUIRED';end if;
 if exists(select 1 from capi_private.admin_roles where user_id=p_actor) then raise exception 'CLIENT_REQUIRED';end if;
 select balance into available from public.token_balances where user_id=p_actor for update;
 if not found then raise exception 'PROFILE_NOT_READY';end if;
 select * into r from public.code_redemptions where user_id=p_actor and request_id=p_request;
 if found then if r.code_snapshot<>upper(trim(p_code)) then raise exception 'IDEMPOTENCY_CONFLICT';end if;return to_jsonb(r);end if;
 select * into c from public.promo_codes where code=upper(trim(p_code)) for update;
 if not found or not c.active or c.revoked_at is not null or c.uses>=c.max_uses or c.expires_at<=now() then raise exception 'CODE_UNAVAILABLE';end if;
 if c.campaign_id is not null then
 perform 1 from public.campaigns where id=c.campaign_id and active and (starts_at is null or starts_at<=now()) and (expires_at is null or expires_at>now()) for share;
 if not found then raise exception 'CAMPAIGN_UNAVAILABLE';end if;end if;
 if exists(select 1 from public.code_redemptions where user_id=p_actor and code_id=c.id) then raise exception 'ALREADY_REDEEMED';end if;
 insert into public.code_redemptions(user_id,code_id,campaign_id,code_snapshot,tokens_granted,request_id) values(p_actor,c.id,c.campaign_id,c.code,c.tokens,p_request) returning * into r;
 update public.promo_codes set uses=uses+1,revision=revision+1 where id=c.id;
 insert into public.token_movements(user_id,delta,kind,redemption_id) values(p_actor,c.tokens,'code',r.id);
 update public.token_balances set balance=balance+c.tokens,revision=revision+1,updated_at=now() where user_id=p_actor;
 return to_jsonb(r);
end$$;

create function capi_private.validate_wheel(p_version uuid) returns void language plpgsql security invoker set search_path='' as $$begin
 if (select count(*) from public.wheel_segments where version_id=p_version)<>6 or
 (select coalesce(sum(probability_bps),0) from public.wheel_segments where version_id=p_version)<>10000 then raise exception 'INVALID_PROBABILITIES';end if;
end$$;

create function public.capi_server_spin(p_actor uuid,p_version uuid,p_request uuid) returns jsonb
language plpgsql security invoker set search_path='' as $$
 declare v uuid;available bigint;existing public.spins;chosen public.wheel_segments;spin_row public.spins;award_row public.awarded_prizes;draw integer;deadline timestamptz;funding public.code_redemptions;total_weight integer;begin
 if p_actor is null or p_request is null then raise exception 'UNAUTHORIZED';end if;
 if not exists(select 1 from public.profiles where id=p_actor and instagram_requirement_completed_at is not null) then raise exception 'PARTICIPATION_REQUIRED';end if;
 if exists(select 1 from capi_private.admin_roles where user_id=p_actor) then raise exception 'CLIENT_REQUIRED';end if;
 -- All wheel/catalog/inventory writes lock this singleton first. Published draws serialize.
 select published_version_id into v from capi_private.runtime where singleton for update;
 select balance into available from public.token_balances where user_id=p_actor for update;
 if not found then raise exception 'PROFILE_NOT_READY';end if;
 select * into existing from public.spins where user_id=p_actor and request_id=p_request;
 if found then
 if existing.version_id<>p_version then raise exception 'IDEMPOTENCY_CONFLICT';end if;
 return jsonb_build_object('spin',to_jsonb(existing),'award',(select to_jsonb(a) from public.awarded_prizes a where a.spin_id=existing.id));end if;
 if v is null or v<>p_version then raise exception 'CONFIG_CHANGED';end if;
 if available<1 then raise exception 'INSUFFICIENT_TOKENS';end if;
 perform i.prize_id from public.prize_inventory i where prize_id in(select prize_id from public.wheel_segments where version_id=v) order by i.prize_id for update;
 perform capi_private.validate_wheel(v);
 select r.* into funding from public.code_redemptions r where r.user_id=p_actor and (select count(*) from public.spins x where x.redemption_id=r.id)<r.tokens_granted order by r.created_at,r.id limit 1;
 if not found then raise exception 'FUNDING_NOT_FOUND';end if;
 select sum(weight)::integer into total_weight from capi_private.eligible_pool(v,funding.campaign_id);
 if coalesce(total_weight,0)=0 then raise exception 'NO_ELIGIBLE_REWARDS';end if;
 draw:=capi_private.random_range(total_weight);
 with eligible as(select position,sum(weight) over(order by position) cumulative from capi_private.eligible_pool(v,funding.campaign_id))
 select s.* into chosen from public.wheel_segments s join eligible e on e.position=s.position where s.version_id=v and e.cumulative>draw order by e.position limit 1;
 if not found then raise exception 'INVALID_PROBABILITIES';end if;
 insert into public.spins(user_id,request_id,version_id,segment_position,prize_snapshot,draw_bps,redemption_id,campaign_id) values(p_actor,p_request,v,chosen.position,chosen.prize_snapshot,draw,funding.id,funding.campaign_id) returning * into spin_row;
 if chosen.prize_snapshot->>'kind'='prize' then
 update public.prize_inventory set awarded=awarded+1,revision=revision+1 where prize_id=chosen.prize_id and (capacity is null or awarded<capacity);
 if not found then raise exception 'INVENTORY_EXHAUSTED';end if;
 deadline:=least(now()+make_interval(days=>(chosen.prize_snapshot->>'claimDays')::integer),coalesce((chosen.prize_snapshot->>'expiresAt')::timestamptz,'infinity'::timestamptz));
 insert into public.awarded_prizes(user_id,spin_id,prize_id,version_id,prize_snapshot,original_conditions,expires_at)
 values(p_actor,spin_row.id,chosen.prize_id,v,chosen.prize_snapshot,chosen.prize_snapshot->>'conditions',deadline) returning * into award_row;
 insert into capi_private.award_costs(award_id,campaign_id,prize_id,category,cost_cents)
 select award_row.id,funding.campaign_id,p.id,p.category,rp.cost_cents from public.prizes p join capi_private.reward_policies rp on rp.prize_id=p.id where p.id=chosen.prize_id;
 end if;
 insert into public.token_movements(user_id,delta,kind,spin_id) values(p_actor,-1,'spin',spin_row.id);
 update public.token_balances set balance=balance-1,revision=revision+1,updated_at=now() where user_id=p_actor;
 return jsonb_build_object('spin',to_jsonb(spin_row),'award',case when award_row.id is null then null else to_jsonb(award_row) end);
end$$;

create function public.capi_server_publish(p_actor uuid,p_version uuid,p_revision bigint,p_request uuid) returns jsonb
language plpgsql security invoker set search_path='' as $$
 declare v public.wheel_versions;old_version uuid;begin
 perform capi_private.require_permission(p_actor,'wheel');
 select published_version_id into old_version from capi_private.runtime where singleton for update;
 select * into v from public.wheel_versions where id=p_version for update;
 if not found or v.revision<>p_revision or v.status<>'draft' then raise exception 'REVISION_CONFLICT';end if;
 perform capi_private.validate_wheel(v.id);
 update public.wheel_versions set status='archived' where status='published';
 update public.wheel_versions set status='published',published_at=now(),revision=revision+1 where id=v.id returning * into v;
 update capi_private.runtime set published_version_id=v.id,revision=revision+1 where singleton;
 insert into capi_private.admin_audit(actor_id,action,entity_type,entity_id,before_data,after_data,request_id) values(p_actor,'wheel.publish','wheel_versions',v.id,jsonb_build_object('publishedVersionId',old_version),to_jsonb(v),p_request);
 return to_jsonb(v);
end$$;

create function public.capi_server_award_transition(p_actor uuid,p_award uuid,p_revision bigint,p_status public.capi_award_status,p_reason text,p_request uuid) returns jsonb
language plpgsql security invoker set search_path='' as $$
 declare a public.awarded_prizes;prev public.awarded_prizes;ev public.claim_events;begin
 if p_actor is null or p_request is null then raise exception 'UNAUTHORIZED';end if;
 perform singleton from capi_private.runtime where singleton for update;
 select * into a from public.awarded_prizes where id=p_award for update;
 if not found then raise exception 'NOT_FOUND';end if;
 select * into ev from public.claim_events where actor_id=p_actor and request_id=p_request;
 if found then if ev.award_id<>p_award or ev.next_status<>p_status or ev.note<>coalesce(p_reason,'') then raise exception 'IDEMPOTENCY_CONFLICT';end if;return to_jsonb(a);end if;
 if a.revision<>p_revision then raise exception 'REVISION_CONFLICT';end if;
 if p_status='delivered' and exists(select 1 from capi_private.reward_policies rp where rp.prize_id=a.prize_id and rp.daily_limit is not null and (select count(*) from public.awarded_prizes x where x.prize_id=a.prize_id and x.delivered_at >= (date_trunc('day',now() at time zone 'America/Mexico_City') at time zone 'America/Mexico_City'))>=rp.daily_limit) then raise exception 'DAILY_DELIVERY_LIMIT';end if;
 if a.status not in ('pending','claimed') or a.expires_at<=now() then raise exception 'AWARD_CLOSED';end if;
 if p_status='claimed' then
 if a.user_id<>p_actor or a.status<>'pending' then raise exception 'FORBIDDEN';end if;
 else
 perform capi_private.require_permission(p_actor,'deliveries');
 if p_status not in ('delivered','cancelled') then raise exception 'INVALID_TRANSITION';end if;
 if p_status='cancelled' and length(trim(coalesce(p_reason,'')))=0 then raise exception 'REASON_REQUIRED';end if;end if;
 prev:=a;
 update public.awarded_prizes set status=p_status,revision=revision+1,
 claimed_at=case when p_status='claimed' then now() else claimed_at end,
 delivered_at=case when p_status='delivered' then now() else delivered_at end,
 delivered_by=case when p_status='delivered' then p_actor else delivered_by end,
 cancelled_at=case when p_status='cancelled' then now() else cancelled_at end,
 cancelled_by=case when p_status='cancelled' then p_actor else cancelled_by end,
 cancellation_reason=case when p_status='cancelled' then p_reason else cancellation_reason end
 where id=p_award returning * into a;
 insert into public.claim_events(award_id,actor_id,previous_status,next_status,note,request_id) values(a.id,p_actor,prev.status,p_status,coalesce(p_reason,''),p_request);
 if p_status<>'claimed' then insert into capi_private.admin_audit(actor_id,action,entity_type,entity_id,before_data,after_data,request_id) values(p_actor,'award.transition','awarded_prizes',a.id,to_jsonb(prev),to_jsonb(a),p_request);end if;
 return to_jsonb(a);
end$$;

revoke all on function public.capi_server_redeem(uuid,text,uuid) from public,anon,authenticated;
revoke all on function public.capi_server_spin(uuid,uuid,uuid) from public,anon,authenticated;
revoke all on function public.capi_server_publish(uuid,uuid,bigint,uuid) from public,anon,authenticated;
revoke all on function public.capi_server_award_transition(uuid,uuid,bigint,public.capi_award_status,text,uuid) from public,anon,authenticated;
grant execute on function public.capi_server_redeem(uuid,text,uuid) to service_role;
grant execute on function public.capi_server_spin(uuid,uuid,uuid) to service_role;
grant execute on function public.capi_server_publish(uuid,uuid,bigint,uuid) to service_role;
grant execute on function public.capi_server_award_transition(uuid,uuid,bigint,public.capi_award_status,text,uuid) to service_role;
revoke all on all functions in schema capi_private from public,anon;
grant execute on all functions in schema capi_private to service_role;
commit;
