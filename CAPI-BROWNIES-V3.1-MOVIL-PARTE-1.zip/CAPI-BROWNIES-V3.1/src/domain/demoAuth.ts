import {sha256} from '@noble/hashes/sha256';
import {bytesToHex,utf8ToBytes} from '@noble/hashes/utils';
import {uid,type MockService,type User} from './service';
const KEY='capi-demo-identities-v3';
interface Entry {userId:string;emailHash:string;salt:string;passwordHash:string}
const hash=(value:string)=>bytesToHex(sha256(utf8ToBytes(value)));
// Demo-only credentials. Not an authentication boundary. Never use for real accounts.
export class DemoAuthService {
 constructor(private service:MockService){}
 private entries():Entry[]{return JSON.parse(localStorage.getItem(KEY)||'[]')}
 async register(name:string,email:string,password:string,confirm:string){
  if(!name.trim()||name.trim().length>50)throw new Error('Escribe tu nombre.');
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error('Revisa tu correo.');
  if(password.length<8)throw new Error('Usa al menos 8 caracteres.');
  if(password!==confirm)throw new Error('Las contraseñas no coinciden.');
  const emailHash=hash(email.trim().toLowerCase());const entries=this.entries();
  if(entries.some(x=>x.emailHash===emailHash))throw new Error('Este correo demo ya tiene cuenta. Inicia sesión.');
  const user=await this.service.execute('guest','demo.user',{name}) as User;
  const salt=uid();localStorage.setItem(KEY,JSON.stringify([...entries,{userId:user.id,emailHash,salt,passwordHash:hash(salt+password)}]));return user;
 }
 async login(email:string,password:string){const entry=this.entries().find(x=>x.emailHash===hash(email.trim().toLowerCase()));if(!entry||entry.passwordHash!==hash(entry.salt+password))throw new Error('Correo o contraseña demo incorrectos.');const view=await this.service.getView(entry.userId);return view.users.find(u=>u.id===entry.userId)!}
 reset(){localStorage.removeItem(KEY)}
}
