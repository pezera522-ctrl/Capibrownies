import {defineConfig} from 'vitest/config';
export default defineConfig({test:{environment:'jsdom',include:['tests/admin-flow.test.tsx'],testTimeout:45000},esbuild:{jsx:'automatic'}});
