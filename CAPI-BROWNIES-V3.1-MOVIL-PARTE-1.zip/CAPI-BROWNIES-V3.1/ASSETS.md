# Recursos originales y rutas

Los ocho PNG del repositorio se conservan byte por byte, sin renombrar. Se sirven desde `public/assets/capi/`.

| Archivo exacto | Uso real |
|---|---|
| `capi-logo-completo.PNG` | Logo en bienvenida y encabezados |
| `capi-mascota.PNG` | Perfil |
| `brownies-floating.PNG` | Brownies flotantes |
| `chocolate-swirl-frase.PNG` | Remolinos de chocolate |
| `capi-bg-main-vertical .PNG` | Fondo; **espacio antes del punto** |
| `capi-wheel-decorative.PNG` | Contiene el pedestal; usado debajo de la ruleta |
| `capi-wheel-podium.PNG` | Contiene la pincelada; usado detrás de títulos |
| `brisa-peach.PNG` | Destellos dorados y celebración |

URL del fondo: `/assets/capi/capi-bg-main-vertical%20.PNG`. Los nombres de pedestal/pincelada no coinciden con su contenido; el código los asigna por su imagen real.

## Pendientes opcionales

La demo funciona sin estos archivos. Añadirlos después en las rutas siguientes y asignarlos desde Gestionar premios → URL de imagen → publicar nueva configuración:

- `/assets/capi/premio-brownie.png`
- `/assets/capi/premio-descuento.png`
- `/assets/capi/premio-2x1.png`
- `/assets/capi/premio-topping.png`
- `/assets/capi/premio-envio.png`
- `/assets/capi/premio-reintento.png`
- `/assets/capi/wheel-frame.png`: marco decorativo transparente opcional; ninguno de los ocho PNG incluye una ruleta. Los seis segmentos funcionales y el resultado se dibujan desde configuración dinámica.

Actualmente se usan iconos Phosphor en premios. No se han generado imágenes sustitutas para V3.
